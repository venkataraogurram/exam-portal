// Backend Elastic Beanstalk URL
const API_URL = 'https://api.venkatgh.people.aws.dev';

function showAuthTab(tab) {
    // Remove active from all tabs and forms
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    
    // Add active to selected tab and form
    if (tab === 'login') {
        document.querySelectorAll('.auth-tab')[0].classList.add('active');
        document.getElementById('login-form').classList.add('active');
    } else if (tab === 'register') {
        document.querySelectorAll('.auth-tab')[1].classList.add('active');
        document.getElementById('register-form').classList.add('active');
    }
}

function showForgotPassword() {
    // Remove active from all tabs and forms
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    
    // Show forgot password form
    document.getElementById('forgot-form').classList.add('active');
}

// Login
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const messageDiv = document.getElementById('login-message');
    
    try {
        const response = await fetch(`${API_URL}/api/student/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Store student info
            localStorage.setItem('student', JSON.stringify(result.student));
            messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Login successful! Redirecting...</p>';
            setTimeout(() => {
                window.location.href = 'student-dashboard.html';
            }, 1000);
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Login error:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Login failed. Please try again.</p>';
    }
});

// Register
document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const full_name = document.getElementById('register-name').value;
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-confirm').value;
    const messageDiv = document.getElementById('register-message');
    
    if (password !== confirm) {
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Passwords do not match</p>';
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/student/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, full_name, username })
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Registration successful! Logging you in...</p>';
            
            // Auto-login after successful registration
            try {
                const loginResponse = await fetch(`${API_URL}/api/student/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: username || email, password })
                });
                
                const loginResult = await loginResponse.json();
                
                if (loginResult.success) {
                    // Store student info
                    localStorage.setItem('student', JSON.stringify(loginResult.student));
                    messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Welcome! Redirecting to dashboard...</p>';
                    setTimeout(() => {
                        window.location.href = 'student-dashboard.html';
                    }, 1000);
                } else {
                    // If auto-login fails, redirect to login page
                    messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Registration successful! Please login.</p>';
                    setTimeout(() => {
                        showAuthTab('login');
                        document.getElementById('login-email').value = username || email;
                    }, 1500);
                }
            } catch (loginError) {
                console.error('Auto-login error:', loginError);
                // If auto-login fails, redirect to login page
                messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Registration successful! Please login.</p>';
                setTimeout(() => {
                    showAuthTab('login');
                    document.getElementById('login-email').value = username || email;
                }, 1500);
            }
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Registration error:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Registration failed. Please try again.</p>';
    }
});

// Forgot Password
document.getElementById('forgot-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('forgot-email').value;
    const messageDiv = document.getElementById('forgot-message');
    
    try {
        const response = await fetch(`${API_URL}/api/student/forgot-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = `<p class="text-success"><i class="fas fa-check-circle"></i> ${result.message}</p>`;
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Forgot password error:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Request failed. Please try again.</p>';
    }
});
