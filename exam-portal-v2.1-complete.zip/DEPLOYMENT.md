# Detailed Deployment Guide - Exam Portal

This guide provides step-by-step instructions for deploying the Exam Portal application to AWS Elastic Beanstalk.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [AWS Account Setup](#aws-account-setup)
3. [RDS Database Setup](#rds-database-setup)
4. [Backend Deployment](#backend-deployment)
5. [Frontend Deployment](#frontend-deployment)
6. [Post-Deployment Configuration](#post-deployment-configuration)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### 1. Install Required Tools

#### AWS CLI
```bash
# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Windows
# Download and run: https://awscli.amazonaws.com/AWSCLIV2.msi

# Verify installation
aws --version
```

#### EB CLI
```bash
pip install awsebcli --upgrade --user

# Verify installation
eb --version
```

#### Python 3.8+
```bash
python3 --version
# Should show 3.8 or higher
```

### 2. Configure AWS Credentials

```bash
aws configure
```

Enter:
- AWS Access Key ID: `[Your Access Key]`
- AWS Secret Access Key: `[Your Secret Key]`
- Default region name: `us-east-1`
- Default output format: `json`

---

## AWS Account Setup

### 1. Create IAM User (if needed)

1. Go to AWS Console → IAM → Users
2. Click "Add users"
3. Username: `exam-portal-deployer`
4. Access type: Programmatic access
5. Attach policies:
   - `AWSElasticBeanstalkFullAccess`
   - `AmazonRDSFullAccess`
   - `AmazonEC2FullAccess`
   - `IAMFullAccess` (for creating service roles)
6. Save Access Key ID and Secret Access Key

### 2. Create EC2 Key Pair (Optional, for SSH access)

```bash
aws ec2 create-key-pair --key-name exam-portal-key --query 'KeyMaterial' --output text > exam-portal-key.pem
chmod 400 exam-portal-key.pem
```

---

## RDS Database Setup

### Option 1: Create RDS via AWS Console

#### Step 1: Navigate to RDS
1. Go to AWS Console → RDS
2. Click "Create database"

#### Step 2: Choose Database Settings
- **Engine**: MySQL
- **Version**: MySQL 8.0.x (latest)
- **Template**: Free tier (or Dev/Test for production)

#### Step 3: Settings
- **DB instance identifier**: `exam-portal-db`
- **Master username**: `admin`
- **Master password**: Choose a secure password (e.g., `Admin123!`)
- **Confirm password**: Re-enter password

#### Step 4: Instance Configuration
- **DB instance class**: db.t2.micro (free tier) or db.t3.micro
- **Storage**: 20 GB (General Purpose SSD)
- **Enable storage autoscaling**: Yes (optional)

#### Step 5: Connectivity
- **VPC**: Default VPC
- **Public access**: Yes (for initial setup, restrict later)
- **VPC security group**: Create new
  - Name: `exam-portal-db-sg`
- **Availability Zone**: No preference

#### Step 6: Additional Configuration
- **Initial database name**: `examportal`
- **Backup retention**: 7 days
- **Enable encryption**: Yes (recommended)

#### Step 7: Create Database
- Click "Create database"
- Wait 5-10 minutes for creation
- Note the **Endpoint** (e.g., `exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com`)

### Option 2: Create RDS via AWS CLI

```bash
aws rds create-db-instance \
  --db-instance-identifier exam-portal-db \
  --db-instance-class db.t2.micro \
  --engine mysql \
  --master-username admin \
  --master-user-password Admin123! \
  --allocated-storage 20 \
  --db-name examportal \
  --backup-retention-period 7 \
  --publicly-accessible \
  --region us-east-1

# Wait for creation
aws rds wait db-instance-available --db-instance-identifier exam-portal-db

# Get endpoint
aws rds describe-db-instances --db-instance-identifier exam-portal-db --query 'DBInstances[0].Endpoint.Address' --output text
```

### Step 8: Configure Security Group

```bash
# Get your IP address
MY_IP=$(curl -s https://checkip.amazonaws.com)

# Get RDS security group ID
SG_ID=$(aws rds describe-db-instances \
  --db-instance-identifier exam-portal-db \
  --query 'DBInstances[0].VpcSecurityGroups[0].VpcSecurityGroupId' \
  --output text)

# Allow your IP to access RDS
aws ec2 authorize-security-group-ingress \
  --group-id $SG_ID \
  --protocol tcp \
  --port 3306 \
  --cidr $MY_IP/32
```

### Step 9: Test Database Connection

```bash
# Install MySQL client (if not installed)
# macOS: brew install mysql-client
# Linux: sudo apt-get install mysql-client

# Connect to RDS
mysql -h exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com -u admin -p

# Enter password when prompted
# Run: SHOW DATABASES;
# You should see 'examportal'
```

### Step 10: Initialize Database

Update `setup_db.py` with your RDS credentials:

```python
DB_CONFIG = {
    'host': 'exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'Admin123!',
    'database': 'examportal',
    'port': 3306
}
```

Run the setup script:

```bash
python3 setup_db.py
```

---

## Backend Deployment

### Step 1: Navigate to Backend Directory

```bash
cd backend
```

### Step 2: Update Environment Configuration

Edit `backend/.ebextensions/environment.config`:

```yaml
option_settings:
  aws:elasticbeanstalk:application:environment:
    DB_HOST: "exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com"
    DB_USER: "admin"
    DB_PASSWORD: "Admin123!"
    DB_NAME: "examportal"
    DB_PORT: "3306"
```

### Step 3: Initialize Elastic Beanstalk

```bash
eb init

# Select:
# 1. Region: us-east-1 (or your preferred region)
# 2. Application name: exam-portal-backend
# 3. Platform: Python
# 4. Platform version: Python 3.8
# 5. SSH: Yes (optional)
# 6. Key pair: exam-portal-key (if created)
```

Or use one command:

```bash
eb init -p python-3.8 exam-portal-backend --region us-east-1
```

### Step 4: Create Environment

```bash
eb create exam-backend-env \
  --instance-type t2.micro \
  --envvars DB_HOST=exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com,DB_USER=admin,DB_PASSWORD=Admin123!,DB_NAME=examportal,DB_PORT=3306
```

Wait 5-10 minutes for environment creation.

### Step 5: Verify Backend Deployment

```bash
# Check status
eb status

# Get URL
eb open

# Test API
curl http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com/
# Should return: {"message": "Exam Portal API", "status": "running"}
```

### Step 6: Get Backend Security Group

```bash
# Get backend EC2 instance ID
INSTANCE_ID=$(aws elasticbeanstalk describe-environment-resources \
  --environment-name exam-backend-env \
  --query 'EnvironmentResources.Instances[0].Id' \
  --output text)

# Get security group ID
BACKEND_SG=$(aws ec2 describe-instances \
  --instance-ids $INSTANCE_ID \
  --query 'Reservations[0].Instances[0].SecurityGroups[0].GroupId' \
  --output text)

echo "Backend Security Group: $BACKEND_SG"
```

### Step 7: Allow Backend to Access RDS

```bash
# Get RDS security group
RDS_SG=$(aws rds describe-db-instances \
  --db-instance-identifier exam-portal-db \
  --query 'DBInstances[0].VpcSecurityGroups[0].VpcSecurityGroupId' \
  --output text)

# Add rule to allow backend access
aws ec2 authorize-security-group-ingress \
  --group-id $RDS_SG \
  --protocol tcp \
  --port 3306 \
  --source-group $BACKEND_SG
```

### Step 8: Initialize Database Tables

```bash
# Call init endpoint
BACKEND_URL=$(eb status | grep CNAME | awk '{print $2}')
curl -X POST http://$BACKEND_URL/api/init-db
```

---

## Frontend Deployment

### Step 1: Navigate to Frontend Directory

```bash
cd ../frontend
```

### Step 2: Update API URLs

Get your backend URL:

```bash
cd ../backend
eb status | grep CNAME
# Copy the URL (e.g., exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com)
cd ../frontend
```

Update `API_URL` in these files:

**frontend/admin.js:**
```javascript
const API_URL = 'http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com';
```

**frontend/student-auth.js:**
```javascript
const API_URL = 'http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com';
```

**frontend/student-dashboard.js:**
```javascript
const API_URL = 'http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com';
```

**frontend/student-profile.js:**
```javascript
const API_URL = 'http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com';
```

### Step 3: Initialize Elastic Beanstalk

```bash
eb init -p python-3.8 exam-portal-frontend --region us-east-1
```

### Step 4: Create Environment with ALB

```bash
eb create exam-frontend-env \
  --instance-type t2.micro \
  --elb-type application
```

Wait 5-10 minutes for environment creation.

### Step 5: Verify Frontend Deployment

```bash
# Check status
eb status

# Open in browser
eb open
```

---

## Post-Deployment Configuration

### 1. Test Admin Login

1. Navigate to: `http://exam-frontend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com/admin.html`
2. Login with:
   - Username: `admin`
   - Password: `admin123`
3. Verify dashboard loads

### 2. Test Student Registration

1. Navigate to: `http://exam-frontend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com/student-auth.html`
2. Click "Register" tab
3. Create a test account
4. Login and verify dashboard

### 3. Create Sample Exam

1. Login as admin
2. Click "Create New Exam"
3. Add exam title
4. Add questions with options
5. Save exam

### 4. Take Sample Exam

1. Login as student
2. Click on exam
3. Answer questions
4. Submit and view results

### 5. Update Security Settings

#### Restrict RDS Access

```bash
# Remove public access rule
aws ec2 revoke-security-group-ingress \
  --group-id $RDS_SG \
  --protocol tcp \
  --port 3306 \
  --cidr $MY_IP/32

# Only backend should access RDS now
```

#### Change Admin Password

```bash
# SSH into backend
cd backend
eb ssh

# Connect to MySQL
mysql -h exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com -u admin -p

# Update password
USE examportal;
UPDATE admin_users SET password = 'NewSecurePassword123!' WHERE username = 'admin';
exit
```

---

## Testing

### Backend API Tests

```bash
BACKEND_URL="http://exam-backend-env.eba-xxxxx.us-east-1.elasticbeanstalk.com"

# Test health
curl $BACKEND_URL/

# Test admin login
curl -X POST $BACKEND_URL/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Test get exams
curl $BACKEND_URL/api/exams

# Test student registration
curl -X POST $BACKEND_URL/api/student/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","full_name":"Test User"}'
```

### Frontend Tests

1. **Admin Portal**: `/admin.html`
   - Login
   - Create exam
   - Add questions
   - Manage students
   - View results

2. **Student Portal**: `/student-auth.html`
   - Register
   - Login
   - View exams
   - Take exam
   - View results
   - Update profile

---

## Troubleshooting

### Issue: Backend 502 Bad Gateway

**Solution:**
```bash
# Check logs
cd backend
eb logs

# Look for Python errors
# Common issues:
# - Missing dependencies in requirements.txt
# - Database connection errors
# - Port configuration (should be 8080)
```

### Issue: Database Connection Failed

**Solution:**
```bash
# Verify environment variables
cd backend
eb printenv

# Test connection from EC2
eb ssh
telnet exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com 3306

# Check security group rules
aws ec2 describe-security-groups --group-ids $RDS_SG
```

### Issue: CORS Errors in Frontend

**Solution:**
- Verify `CORS(app)` is in backend/app.py
- Check API_URL in frontend files matches backend URL
- Ensure backend is accessible from browser

### Issue: Admin Login Not Working

**Solution:**
- Check browser console for JavaScript errors
- Verify Font Awesome CDN is loading
- Ensure admin.js is loaded (not admin-modern.js)
- Test backend endpoint directly:
  ```bash
  curl -X POST $BACKEND_URL/api/admin/login \
    -H "Content-Type: application/json" \
    -d '{"username":"admin","password":"admin123"}'
  ```

### Issue: Student Results Not Showing

**Solution:**
```bash
# Check if student_id column exists
eb ssh
mysql -h exam-portal-db.xxxxx.us-east-1.rds.amazonaws.com -u admin -p
USE examportal;
SHOW COLUMNS FROM results;

# If missing, add column:
ALTER TABLE results ADD COLUMN student_id INT AFTER exam_id;
```

---

## Monitoring and Maintenance

### View Logs

```bash
# Backend logs
cd backend
eb logs

# Frontend logs
cd frontend
eb logs

# Tail logs in real-time
eb logs --stream
```

### Monitor Health

```bash
# Check environment health
eb health

# View detailed health
eb health --refresh
```

### Update Application

```bash
# Backend update
cd backend
# Make changes
eb deploy

# Frontend update
cd frontend
# Make changes
eb deploy
```

### Scale Application

```bash
# Scale to 2 instances
eb scale 2

# Enable auto-scaling
eb config
# Edit: aws:autoscaling:asg
```

---

## Cost Estimation

### Free Tier (First 12 months):
- EC2 t2.micro: 750 hours/month (2 instances = free)
- RDS db.t2.micro: 750 hours/month (free)
- ALB: 750 hours/month (free)
- Data transfer: 15 GB/month (free)

### After Free Tier:
- EC2 t2.micro: ~$8.50/month per instance
- RDS db.t2.micro: ~$15/month
- ALB: ~$16/month
- **Total**: ~$48/month (2 EC2 + 1 RDS + 1 ALB)

### Cost Optimization:
1. Use t2.micro instances
2. Enable auto-scaling (scale down during low traffic)
3. Use RDS reserved instances (save up to 60%)
4. Set up billing alerts

---

## Cleanup (To Avoid Charges)

```bash
# Terminate frontend
cd frontend
eb terminate exam-frontend-env

# Terminate backend
cd ../backend
eb terminate exam-backend-env

# Delete RDS (creates final snapshot)
aws rds delete-db-instance \
  --db-instance-identifier exam-portal-db \
  --final-db-snapshot-identifier exam-portal-db-final-snapshot

# Or delete without snapshot
aws rds delete-db-instance \
  --db-instance-identifier exam-portal-db \
  --skip-final-snapshot
```

---

## Next Steps

1. **Set up HTTPS**: Use AWS Certificate Manager + CloudFront
2. **Custom Domain**: Route 53 + CloudFront
3. **CI/CD**: GitHub Actions or AWS CodePipeline
4. **Monitoring**: CloudWatch dashboards and alarms
5. **Backup**: Automated RDS snapshots
6. **Security**: WAF, password hashing, JWT tokens

---

**Deployment Complete! 🎉**

Your exam portal is now live and ready to use!
