# Exam Import File Format

This document explains how to create text files for importing exams into the Exam Portal.

## File Format

The exam file should be a plain text file (.txt) with the following structure:

```
EXAM_TITLE: Your Exam Title Here

QUESTION: Your question text here?
A) First option
B) Second option
C) Third option
D) Fourth option
CORRECT: B

QUESTION: Next question here?
A) Option 1
B) Option 2
C) Option 3
D) Option 4
CORRECT: C
```

## Format Rules

1. **Exam Title** (Required)
   - Start with `EXAM_TITLE:` followed by your exam title
   - Must be on the first line (can have blank lines before it)
   - Example: `EXAM_TITLE: Basic Mathematics Quiz`

2. **Questions** (Required, at least 1)
   - Start with `QUESTION:` followed by the question text
   - Each question must have exactly 4 options (A, B, C, D)
   - Options must start with `A)`, `B)`, `C)`, or `D)` followed by the option text
   - Must specify the correct answer with `CORRECT:` followed by the letter (A, B, C, or D)

3. **Spacing**
   - Blank lines between questions are optional but recommended for readability
   - Leading/trailing spaces are automatically trimmed

4. **Character Support**
   - Supports all UTF-8 characters
   - Can include mathematical symbols, special characters, etc.

## Example Files

### Example 1: Simple Math Quiz

```
EXAM_TITLE: Basic Mathematics Quiz

QUESTION: What is 15 + 27?
A) 40
B) 42
C) 44
D) 45
CORRECT: B

QUESTION: What is 8 × 7?
A) 54
B) 55
C) 56
D) 57
CORRECT: C

QUESTION: What is 144 ÷ 12?
A) 10
B) 11
C) 12
D) 13
CORRECT: C
```

### Example 2: Science Quiz

```
EXAM_TITLE: Basic Science Knowledge

QUESTION: What is the chemical symbol for water?
A) H2O
B) CO2
C) O2
D) N2
CORRECT: A

QUESTION: What planet is known as the Red Planet?
A) Venus
B) Mars
C) Jupiter
D) Saturn
CORRECT: B

QUESTION: What is the speed of light?
A) 300,000 km/s
B) 150,000 km/s
C) 450,000 km/s
D) 600,000 km/s
CORRECT: A
```

### Example 3: Programming Quiz

```
EXAM_TITLE: Python Programming Basics

QUESTION: Which keyword is used to define a function in Python?
A) function
B) def
C) func
D) define
CORRECT: B

QUESTION: What is the output of: print(2 ** 3)?
A) 6
B) 8
C) 9
D) 23
CORRECT: B

QUESTION: Which data type is mutable in Python?
A) tuple
B) string
C) list
D) int
CORRECT: C
```

## How to Import

1. **Create Your File**
   - Create a new text file (.txt)
   - Follow the format above
   - Save the file

2. **Import via Admin Console**
   - Login to admin console
   - Go to "Manage Exams" tab
   - Click "Import from File" button
   - Select your .txt file
   - Preview the content
   - Click "Import Exam"

3. **Verify**
   - The exam will appear in your exams list
   - Click "Edit" to verify all questions were imported correctly

## Common Mistakes to Avoid

❌ **Wrong:**
```
QUESTION What is 2+2?  (Missing colon)
A 4                     (Missing parenthesis)
CORRECT B              (Missing colon)
```

✅ **Correct:**
```
QUESTION: What is 2+2?
A) 4
B) 5
C) 6
D) 7
CORRECT: A
```

❌ **Wrong:**
```
QUESTION: What is 2+2?
A) 4
B) 5
CORRECT: A              (Only 2 options, need 4)
```

✅ **Correct:**
```
QUESTION: What is 2+2?
A) 4
B) 5
C) 6
D) 7
CORRECT: A
```

## Tips

1. **Use a Plain Text Editor**
   - Use Notepad (Windows), TextEdit (Mac), or any code editor
   - Don't use Word or rich text editors

2. **Test with Small Files First**
   - Start with 2-3 questions to test the format
   - Once working, create larger exams

3. **Keep Backups**
   - Save your exam files for future use
   - You can modify and re-import them

4. **Question Limits**
   - No limit on number of questions
   - Recommended: 10-50 questions per exam for best student experience

5. **Reusability**
   - Save your exam files in a folder
   - Share them with other admins
   - Modify and re-import as needed

## Sample Files Included

- `sample-math-exam.txt` - 10 basic math questions
- Create your own following the same format!

## Troubleshooting

**Problem**: "No valid questions found in file"
- **Solution**: Check that each question has QUESTION:, 4 options (A-D), and CORRECT: line

**Problem**: "Import failed"
- **Solution**: Verify file format matches examples exactly, check for typos in keywords

**Problem**: Questions missing after import
- **Solution**: Ensure each question has exactly 4 options and a CORRECT: line

**Problem**: Wrong answers marked as correct
- **Solution**: Double-check CORRECT: letter matches the intended answer option

## Need Help?

If you encounter issues:
1. Compare your file with the sample files
2. Check for missing colons, parentheses, or keywords
3. Ensure file is saved as plain text (.txt)
4. Try importing the sample file first to verify the feature works

---

**Happy Exam Creating!** 📝
