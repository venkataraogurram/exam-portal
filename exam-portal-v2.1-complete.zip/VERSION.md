# Exam Portal - Version History

## Version 2.1 - December 27, 2025

### New Features
- **Edit Student Details**: Admins can now edit student name, username, and email
- **Exam Assignment System**: Assign specific exams to selected students
- **Auto-Login After Registration**: Students automatically logged in after successful registration
- **Responsive Design**: Full mobile and tablet support
- **Portfolio Ready**: Complete documentation and architecture diagrams

### Improvements
- Enhanced student management interface
- Better validation for duplicate emails and usernames
- Improved error messages and user feedback
- Mobile-optimized UI for all pages

### Bug Fixes
- Fixed database connection issues
- Resolved CORS configuration
- Fixed JavaScript syntax errors
- Improved error handling across the application

---

## Version 2.0 - December 27, 2025

### Major Updates
- **HTTPS Support**: Full HTTPS implementation for both frontend and backend
- **Application Load Balancer**: Migrated from single instance to ALB architecture
- **Custom Domain**: exam.venkatgh.people.aws.dev and api.venkatgh.people.aws.dev
- **Database Connection Fixed**: Added DB_PASSWORD to environment configuration

### Features Added
- Username support for students (login with email or username)
- Exam import from text files
- Admin management system (root admin can manage other admins)
- Modern UI with Font Awesome icons and Inter font

---

## Version 1.0 - December 2025

### Initial Release
- Admin authentication and management
- Student registration and authentication
- Exam creation and management
- Question management with multiple choice options
- Results tracking and reporting
- Student management (add, activate/deactivate, delete, reset password)

### Architecture
- Backend: Flask API on AWS Elastic Beanstalk
- Frontend: Static HTML/CSS/JS on AWS Elastic Beanstalk
- Database: MySQL on AWS RDS
