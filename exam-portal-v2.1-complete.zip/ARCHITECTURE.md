# Exam Portal - AWS Architecture

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              Internet Users                              │
│                    (Students, Admins, Mobile Devices)                    │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                                 │ HTTPS
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                          Amazon Route 53                                 │
│                         (DNS Management)                                 │
│                                                                           │
│  • exam.venkatgh.people.aws.dev    → Frontend ALB                       │
│  • api.venkatgh.people.aws.dev     → Backend ALB                        │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                    ┌────────────┴────────────┐
                    │                         │
                    ▼                         ▼
┌──────────────────────────────┐  ┌──────────────────────────────┐
│   AWS Certificate Manager    │  │   AWS Certificate Manager    │
│   (SSL/TLS Certificate)      │  │   (SSL/TLS Certificate)      │
│   *.venkatgh.people.aws.dev  │  │   *.venkatgh.people.aws.dev  │
└──────────────┬───────────────┘  └──────────────┬───────────────┘
               │                                  │
               ▼                                  ▼
┌──────────────────────────────┐  ┌──────────────────────────────┐
│  Application Load Balancer   │  │  Application Load Balancer   │
│      (Frontend ALB)           │  │      (Backend ALB)           │
│                               │  │                               │
│  • HTTPS Listener (443)       │  │  • HTTPS Listener (443)       │
│  • Health Checks              │  │  • Health Checks              │
│  • Security Group             │  │  • Security Group             │
└──────────────┬───────────────┘  └──────────────┬───────────────┘
               │                                  │
               ▼                                  ▼
┌──────────────────────────────┐  ┌──────────────────────────────┐
│  Elastic Beanstalk Env       │  │  Elastic Beanstalk Env       │
│  (exam-frontend-env)         │  │  (exam-backend-alb)          │
│                               │  │                               │
│  ┌─────────────────────────┐ │  │  ┌─────────────────────────┐ │
│  │   EC2 Instance(s)       │ │  │  │   EC2 Instance(s)       │ │
│  │   • Nginx               │ │  │  │   • Python 3.11         │ │
│  │   • Static Files        │ │  │  │   • Flask API           │ │
│  │   • HTML/CSS/JS         │ │  │  │   • Gunicorn            │ │
│  │   • Modern UI           │ │  │  │   • PyMySQL             │ │
│  └─────────────────────────┘ │  │  └──────────┬──────────────┘ │
│                               │  │             │                 │
│  Auto Scaling Group           │  │  Auto Scaling Group          │
└───────────────────────────────┘  └─────────────┼────────────────┘
                                                  │
                                                  │ MySQL Protocol
                                                  │ (Port 3306)
                                                  ▼
                                   ┌──────────────────────────────┐
                                   │   Amazon RDS MySQL           │
                                   │   (venkat-rds)               │
                                   │                               │
                                   │  • Multi-AZ (Optional)        │
                                   │  • Automated Backups          │
                                   │  • Security Group             │
                                   │  • Database: examportal       │
                                   │                               │
                                   │  Tables:                      │
                                   │  • admin_users                │
                                   │  • students                   │
                                   │  • exams                      │
                                   │  • questions                  │
                                   │  • results                    │
                                   │  • exam_assignments           │
                                   └───────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                        Supporting Services                               │
├─────────────────────────────────────────────────────────────────────────┤
│  • Amazon S3: Application version storage                                │
│  • CloudWatch: Logs and monitoring                                       │
│  • IAM: Roles and permissions                                            │
│  • VPC: Network isolation and security                                   │
│  • Security Groups: Firewall rules                                       │
└─────────────────────────────────────────────────────────────────────────┘
```

## Architecture Components

### 1. Frontend Layer
- **Service**: AWS Elastic Beanstalk (Python platform)
- **Environment**: exam-frontend-env
- **Load Balancer**: Application Load Balancer with HTTPS
- **Domain**: https://exam.venkatgh.people.aws.dev
- **Content**: Static HTML, CSS, JavaScript files
- **Features**:
  - Modern responsive UI
  - Student portal
  - Admin console
  - Mobile-friendly design

### 2. Backend Layer
- **Service**: AWS Elastic Beanstalk (Python 3.11)
- **Environment**: exam-backend-alb
- **Load Balancer**: Application Load Balancer with HTTPS
- **Domain**: https://api.venkatgh.people.aws.dev
- **Framework**: Flask REST API
- **Features**:
  - RESTful API endpoints
  - CORS enabled
  - Authentication
  - Exam management
  - Student management

### 3. Database Layer
- **Service**: Amazon RDS MySQL
- **Instance**: venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com
- **Database**: examportal
- **Features**:
  - Persistent data storage
  - Automated backups
  - Security group protection
  - Connection pooling

### 4. Security & Networking
- **SSL/TLS**: AWS Certificate Manager (*.venkatgh.people.aws.dev)
- **DNS**: Amazon Route 53
- **Security Groups**:
  - Frontend ALB: Allows HTTPS (443) from internet
  - Backend ALB: Allows HTTPS (443) from internet
  - RDS: Allows MySQL (3306) from backend EC2 instances
- **VPC**: Default VPC with public subnets

### 5. Monitoring & Logging
- **CloudWatch Logs**: Application and access logs
- **CloudWatch Metrics**: CPU, memory, network usage
- **Health Checks**: ALB health checks for EC2 instances

## Data Flow

### Student Exam Flow
1. Student accesses https://exam.venkatgh.people.aws.dev
2. Route 53 resolves to Frontend ALB
3. ALB forwards to Frontend EC2 instance
4. Student logs in → API call to Backend ALB
5. Backend validates credentials against RDS
6. Student takes exam → Answers sent to Backend API
7. Backend calculates score and stores in RDS
8. Results displayed to student

### Admin Management Flow
1. Admin accesses https://exam.venkatgh.people.aws.dev/admin.html
2. Admin logs in → Backend validates against RDS
3. Admin creates/edits exams → Backend stores in RDS
4. Admin assigns exams to students → Backend updates exam_assignments table
5. Admin views results → Backend fetches from RDS

## Scalability Features

### Horizontal Scaling
- Auto Scaling Groups for both frontend and backend
- Load balancers distribute traffic across multiple instances
- Stateless application design

### Vertical Scaling
- RDS instance can be upgraded for more capacity
- EC2 instance types can be changed

### High Availability
- Multi-AZ deployment option for RDS
- Multiple availability zones for EC2 instances
- Health checks and automatic instance replacement

## Security Best Practices

1. **Encryption in Transit**: HTTPS/TLS for all communications
2. **Encryption at Rest**: RDS encryption (optional)
3. **Network Isolation**: Security groups restrict access
4. **Least Privilege**: IAM roles with minimal permissions
5. **Authentication**: Password-based authentication for users
6. **Input Validation**: Backend validates all inputs

## Cost Optimization

- **Elastic Beanstalk**: Pay only for EC2 instances used
- **RDS**: Single-AZ for development, Multi-AZ for production
- **ALB**: Pay per hour and per GB processed
- **Route 53**: Pay per hosted zone and queries
- **S3**: Minimal cost for application versions

## Deployment Process

1. **Code Update**: Developer updates code locally
2. **EB CLI**: `eb deploy` command packages and uploads
3. **S3 Storage**: Application version stored in S3
4. **Rolling Update**: Elastic Beanstalk updates instances
5. **Health Check**: ALB verifies instance health
6. **Traffic Routing**: ALB routes traffic to healthy instances

## Monitoring & Alerts

- **Application Logs**: `/var/log/web.stdout.log`
- **Access Logs**: ALB access logs
- **Error Tracking**: CloudWatch Logs Insights
- **Performance Metrics**: CloudWatch dashboards
- **Alarms**: CloudWatch alarms for critical metrics

## Backup & Recovery

- **RDS Automated Backups**: Daily snapshots
- **Application Versions**: Stored in S3
- **Configuration**: Stored in `.elasticbeanstalk/` directory
- **Database Export**: Manual MySQL dumps for critical data

## Future Enhancements

1. **CloudFront CDN**: Faster content delivery globally
2. **ElastiCache**: Redis for session management
3. **S3 + CloudFront**: Static asset hosting
4. **Lambda**: Serverless functions for background tasks
5. **SES**: Email notifications for exam results
6. **Cognito**: Advanced user authentication
7. **API Gateway**: API management and throttling
8. **WAF**: Web Application Firewall for security
