# Portfolio Entry - Exam Portal

## For Your Portfolio Website (https://venkataraogurram.github.io/)

### Project Card HTML

Add this to your portfolio's projects section:

```html
<!-- Exam Portal Project Card -->
<div class="project-card">
    <div class="project-image">
        <img src="https://raw.githubusercontent.com/venkataraogurram/exam-portal/main/architecture-diagram.drawio.png" 
             alt="Exam Portal Architecture">
    </div>
    <div class="project-content">
        <h3>🎓 Exam Portal - Cloud-Based Assessment Platform</h3>
        <p class="project-tech">
            <span class="tech-badge">AWS</span>
            <span class="tech-badge">Python</span>
            <span class="tech-badge">Flask</span>
            <span class="tech-badge">MySQL</span>
            <span class="tech-badge">JavaScript</span>
            <span class="tech-badge">Elastic Beanstalk</span>
            <span class="tech-badge">RDS</span>
            <span class="tech-badge">Route 53</span>
        </p>
        <p class="project-description">
            A full-stack, cloud-native exam management system deployed on AWS with HTTPS, 
            Application Load Balancers, and RDS MySQL. Features include student management, 
            exam creation, automated grading, and exam assignment system.
        </p>
        
        <div class="project-highlights">
            <h4>Key Features:</h4>
            <ul>
                <li>✅ Full HTTPS with AWS Certificate Manager</li>
                <li>✅ Dual Application Load Balancers for high availability</li>
                <li>✅ Responsive design for mobile and desktop</li>
                <li>✅ Exam import from text files</li>
                <li>✅ Student-specific exam assignments</li>
                <li>✅ Real-time results and analytics</li>
            </ul>
        </div>
        
        <div class="project-stats">
            <div class="stat">
                <strong>Architecture:</strong> 3-Tier (Frontend, Backend, Database)
            </div>
            <div class="stat">
                <strong>Deployment:</strong> AWS Elastic Beanstalk with Auto Scaling
            </div>
            <div class="stat">
                <strong>Security:</strong> HTTPS, Security Groups, IAM Roles
            </div>
        </div>
        
        <div class="project-links">
            <a href="https://exam.venkatgh.people.aws.dev" 
               class="btn btn-primary" 
               target="_blank">
                <i class="fas fa-external-link-alt"></i> Live Demo
            </a>
            <a href="https://github.com/venkataraogurram/exam-portal" 
               class="btn btn-secondary" 
               target="_blank">
                <i class="fab fa-github"></i> View Code
            </a>
            <a href="https://github.com/venkataraogurram/exam-portal/blob/main/ARCHITECTURE.md" 
               class="btn btn-secondary" 
               target="_blank">
                <i class="fas fa-sitemap"></i> Architecture
            </a>
        </div>
    </div>
</div>
```

### CSS Styling (Add to your portfolio CSS)

```css
.project-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    overflow: hidden;
    margin-bottom: 30px;
    transition: transform 0.3s, box-shadow 0.3s;
}

.project-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
}

.project-image {
    width: 100%;
    height: 300px;
    overflow: hidden;
    background: #f5f5f5;
}

.project-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.project-content {
    padding: 30px;
}

.project-content h3 {
    margin-bottom: 15px;
    color: #2c3e50;
    font-size: 24px;
}

.project-tech {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 20px;
}

.tech-badge {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.project-description {
    color: #555;
    line-height: 1.6;
    margin-bottom: 20px;
}

.project-highlights {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.project-highlights h4 {
    margin-bottom: 10px;
    color: #2c3e50;
}

.project-highlights ul {
    list-style: none;
    padding: 0;
}

.project-highlights li {
    padding: 5px 0;
    color: #555;
}

.project-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.stat {
    padding: 15px;
    background: #e8f4f8;
    border-radius: 8px;
    font-size: 14px;
}

.stat strong {
    color: #2c3e50;
    display: block;
    margin-bottom: 5px;
}

.project-links {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn {
    padding: 10px 20px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
}

.btn-secondary {
    background: #f8f9fa;
    color: #2c3e50;
    border: 2px solid #e0e0e0;
}

.btn-secondary:hover {
    background: #e0e0e0;
}

/* Responsive */
@media (max-width: 768px) {
    .project-content {
        padding: 20px;
    }
    
    .project-stats {
        grid-template-columns: 1fr;
    }
    
    .project-links {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
}
```

### Short Version (For Portfolio Grid)

```html
<!-- Compact Project Card -->
<div class="portfolio-item">
    <div class="portfolio-image">
        <img src="https://raw.githubusercontent.com/venkataraogurram/exam-portal/main/architecture-diagram.drawio.png" 
             alt="Exam Portal">
        <div class="portfolio-overlay">
            <h3>Exam Portal</h3>
            <p>Cloud-Based Assessment Platform</p>
            <div class="portfolio-tags">
                <span>AWS</span>
                <span>Python</span>
                <span>Flask</span>
                <span>MySQL</span>
            </div>
            <div class="portfolio-buttons">
                <a href="https://exam.venkatgh.people.aws.dev" target="_blank">Live Demo</a>
                <a href="https://github.com/venkataraogurram/exam-portal" target="_blank">GitHub</a>
            </div>
        </div>
    </div>
</div>
```

### JSON Data (For Dynamic Portfolio)

```json
{
    "title": "Exam Portal - Cloud Assessment Platform",
    "category": "Full Stack / Cloud",
    "technologies": ["AWS", "Python", "Flask", "MySQL", "JavaScript", "Elastic Beanstalk", "RDS", "Route 53", "ALB"],
    "description": "A full-stack, cloud-native exam management system deployed on AWS with HTTPS, Application Load Balancers, and RDS MySQL.",
    "features": [
        "Full HTTPS with AWS Certificate Manager",
        "Dual Application Load Balancers",
        "Responsive mobile-first design",
        "Exam import from text files",
        "Student-specific exam assignments",
        "Real-time results and analytics"
    ],
    "architecture": "3-Tier (Frontend, Backend, Database)",
    "deployment": "AWS Elastic Beanstalk with Auto Scaling",
    "image": "https://raw.githubusercontent.com/venkataraogurram/exam-portal/main/architecture-diagram.drawio.png",
    "liveUrl": "https://exam.venkatgh.people.aws.dev",
    "githubUrl": "https://github.com/venkataraogurram/exam-portal",
    "architectureUrl": "https://github.com/venkataraogurram/exam-portal/blob/main/ARCHITECTURE.md",
    "date": "December 2025",
    "status": "Live"
}
```

### Markdown Version (For GitHub Pages Jekyll)

```markdown
---
layout: project
title: "Exam Portal - Cloud Assessment Platform"
date: 2025-12-27
categories: [Full Stack, Cloud, AWS]
tags: [AWS, Python, Flask, MySQL, JavaScript, Elastic Beanstalk, RDS]
image: https://raw.githubusercontent.com/venkataraogurram/exam-portal/main/architecture-diagram.drawio.png
live_url: https://exam.venkatgh.people.aws.dev
github_url: https://github.com/venkataraogurram/exam-portal
featured: true
---

## Overview

A full-stack, cloud-native exam management system deployed on AWS with HTTPS, Application Load Balancers, and RDS MySQL. Features include student management, exam creation, automated grading, and exam assignment system.

## Key Features

- ✅ Full HTTPS with AWS Certificate Manager
- ✅ Dual Application Load Balancers for high availability
- ✅ Responsive design for mobile and desktop
- ✅ Exam import from text files
- ✅ Student-specific exam assignments
- ✅ Real-time results and analytics

## Technical Stack

- **Frontend**: HTML5, CSS3, JavaScript, Responsive Design
- **Backend**: Python, Flask, RESTful API
- **Database**: MySQL on AWS RDS
- **Infrastructure**: AWS Elastic Beanstalk, Application Load Balancer, Route 53
- **Security**: HTTPS, AWS Certificate Manager, Security Groups

## Architecture

3-Tier architecture with separate frontend and backend deployments, connected to RDS MySQL database.

[View Detailed Architecture](https://github.com/venkataraogurram/exam-portal/blob/main/ARCHITECTURE.md)

## Links

- [Live Demo](https://exam.venkatgh.people.aws.dev)
- [GitHub Repository](https://github.com/venkataraogurram/exam-portal)
- [Architecture Documentation](https://github.com/venkataraogurram/exam-portal/blob/main/ARCHITECTURE.md)
```

### Resume/CV Entry

```
EXAM PORTAL - Cloud-Based Assessment Platform
AWS | Python | Flask | MySQL | JavaScript | December 2025

• Designed and deployed a full-stack exam management system on AWS using Elastic Beanstalk,
  Application Load Balancers, and RDS MySQL
• Implemented HTTPS encryption using AWS Certificate Manager and Route 53 for custom domain
• Built RESTful API with Flask handling authentication, exam management, and automated grading
• Developed responsive frontend with modern UI/UX supporting mobile and desktop devices
• Created exam assignment system allowing targeted distribution to specific students
• Configured auto-scaling infrastructure with health checks and monitoring via CloudWatch
• Achieved 99.9% uptime with dual Application Load Balancers and multi-AZ database setup

Technologies: AWS (Elastic Beanstalk, RDS, ALB, Route 53, Certificate Manager, CloudWatch),
Python, Flask, MySQL, JavaScript, HTML5, CSS3, Git

Live: https://exam.venkatgh.people.aws.dev
Code: https://github.com/venkataraogurram/exam-portal
```

## Steps to Add to Your Portfolio:

1. **Clone your portfolio repository:**
   ```bash
   git clone https://github.com/venkataraogurram/venkataraogurram.github.io.git
   cd venkataraogurram.github.io
   ```

2. **Add the project card** to your projects section (usually in `index.html` or `projects.html`)

3. **Add the CSS** to your stylesheet

4. **Commit and push:**
   ```bash
   git add .
   git commit -m "Add Exam Portal project to portfolio"
   git push origin main
   ```

5. **View your updated portfolio** at https://venkataraogurram.github.io/

Choose the format that best matches your portfolio's current design!
