# Exam Portal - Version History

## Version 2.0 - December 27, 2025

### Major Updates
- **HTTPS Support**: Full HTTPS implementation for both frontend and backend
  - Frontend: https://exam.venkatgh.people.aws.dev
  - Backend API: https://api.venkatgh.people.aws.dev
  - SSL Certificate: AWS Certificate Manager (*.venkatgh.people.aws.dev)

- **Application Load Balancer**: Migrated from single instance to ALB architecture
  - Frontend: exam-frontend-env (with ALB)
  - Backend: exam-backend-alb (with ALB)
  - Improved scalability and availability

- **Database Connection Fixed**: 
  - Added DB_PASSWORD to environment configuration
  - Fixed RDS security group rules for new backend
  - Database fully operational with all tables

### Bug Fixes
- Fixed JavaScript syntax error in admin.js (duplicate code block)
- Fixed DNS propagation issues for api.venkatgh.people.aws.dev
- Fixed CORS configuration for cross-origin requests
- Fixed username column in students table

### Technical Details
- RDS: venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com
- Database: examportal
- Security groups properly configured for EC2-RDS communication
- Route53 DNS records configured for custom domains

---

## Version 1.0 - December 2025

### Features
- Admin authentication and management
- Student registration and authentication
- Exam creation and management
- Question management with multiple choice options
- Exam import from text files
- Results tracking and reporting
- Student management (add, activate/deactivate, delete, reset password)
- Username support for students (login with email or username)
- Modern UI with Font Awesome icons and Inter font
- Root admin privileges for admin management

### Architecture
- Backend: Flask API on AWS Elastic Beanstalk
- Frontend: Static HTML/CSS/JS on AWS Elastic Beanstalk
- Database: MySQL on AWS RDS
- Deployment: AWS Elastic Beanstalk with Application Load Balancer
