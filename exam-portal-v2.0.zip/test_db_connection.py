#!/usr/bin/env python3
import socket

# Test basic connectivity
host = 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com'
port = 3306

print(f"Testing connection to {host}:{port}...")

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)
    result = sock.connect_ex((host, port))
    
    if result == 0:
        print("✅ Connection successful! Port 3306 is open.")
        print(f"✅ Your IP (103.168.80.81) can reach the RDS instance.")
    else:
        print(f"❌ Connection failed with error code: {result}")
        print("Check security group rules.")
    
    sock.close()
except Exception as e:
    print(f"❌ Connection error: {e}")

print("\n" + "="*60)
print("RDS Connection Details:")
print("="*60)
print(f"Host: {host}")
print(f"Port: {port}")
print(f"Username: admin")
print(f"Password: Admin123")
print(f"Database: examportal")
print("="*60)
