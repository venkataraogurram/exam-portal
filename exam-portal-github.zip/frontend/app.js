// Backend Elastic Beanstalk URL
const API_URL = 'http://exam-backend-env.eba-eepuvjyu.us-east-1.elasticbeanstalk.com';

let currentExam = null;

async function loadExams() {
    try {
        const response = await fetch(`${API_URL}/api/exams`);
        const exams = await response.json();
        
        const examsDiv = document.getElementById('exams');
        examsDiv.innerHTML = exams.map(exam => `
            <div class="exam-card" onclick="loadExam(${exam.id})">
                <h3>${exam.title}</h3>
                <p>Click to start exam</p>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading exams:', error);
        document.getElementById('exams').innerHTML = '<p>Error loading exams. Make sure backend is running.</p>';
    }
}

async function loadExam(examId) {
    try {
        const response = await fetch(`${API_URL}/api/exams/${examId}`);
        currentExam = await response.json();
        
        document.getElementById('exam-title').textContent = currentExam.title;
        
        const questionsDiv = document.getElementById('questions');
        questionsDiv.innerHTML = currentExam.questions.map(q => `
            <div class="question">
                <h3>Q${q.id}: ${q.question}</h3>
                ${q.options.map((opt, idx) => `
                    <label class="option">
                        <input type="radio" name="q${q.id}" value="${idx}" required>
                        ${opt}
                    </label>
                `).join('')}
            </div>
        `).join('');
        
        document.getElementById('exam-list').classList.add('hidden');
        document.getElementById('exam-view').classList.remove('hidden');
    } catch (error) {
        console.error('Error loading exam:', error);
        alert('Error loading exam');
    }
}

document.getElementById('exam-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const answers = {};
    
    for (let [key, value] of formData.entries()) {
        const questionId = key.substring(1);
        answers[questionId] = parseInt(value);
    }
    
    try {
        const response = await fetch(`${API_URL}/api/submit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                exam_id: currentExam.id,
                answers: answers
            })
        });
        
        const result = await response.json();
        
        document.getElementById('result').innerHTML = `
            <p>You scored:</p>
            <div class="score">${result.score} / ${result.total}</div>
            <p>${Math.round((result.score / result.total) * 100)}%</p>
        `;
        
        document.getElementById('exam-view').classList.add('hidden');
        document.getElementById('result-view').classList.remove('hidden');
    } catch (error) {
        console.error('Error submitting exam:', error);
        alert('Error submitting exam');
    }
});

function showExamList() {
    document.getElementById('exam-view').classList.add('hidden');
    document.getElementById('result-view').classList.add('hidden');
    document.getElementById('exam-list').classList.remove('hidden');
    loadExams();
}

// Load exams on page load
loadExams();
