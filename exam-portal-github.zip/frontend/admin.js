// Backend Elastic Beanstalk URL
const API_URL = 'http://exam-backend-env.eba-eepuvjyu.us-east-1.elasticbeanstalk.com';

let currentAdmin = null;
let currentExam = null;
let questions = [];

// ============ LOGIN ============
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const messageDiv = document.getElementById('login-message');
    
    try {
        const response = await fetch(`${API_URL}/api/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentAdmin = result.username;
            document.getElementById('login-section').classList.add('hidden');
            document.getElementById('admin-section').classList.remove('hidden');
            document.getElementById('admin-name').textContent = currentAdmin;
            loadDashboard();
        } else {
            messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Invalid credentials</p>';
        }
    } catch (error) {
        console.error('Login error:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Login failed</p>';
    }
});

function logout() {
    currentAdmin = null;
    document.getElementById('admin-section').classList.add('hidden');
    document.getElementById('login-section').classList.remove('hidden');
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

// ============ DASHBOARD ============
async function loadDashboard() {
    await Promise.all([loadExams(), loadStudents(), loadResults()]);
}

// ============ TABS ============
function showTab(tab) {
    const clickedButton = event.target;
    document.querySelectorAll('.auth-tab').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
    
    clickedButton.classList.add('active');
    document.getElementById(`${tab}-tab`).classList.remove('hidden');
}

// ============ PROFILE ============
function showProfile() {
    const modal = `
        <div class="modal" onclick="if(event.target===this) closeAllModals()">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title"><i class="fas fa-user-circle"></i> Admin Profile</h2>
                    <button class="modal-close" onclick="closeAllModals()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div style="text-align: center; padding: 30px;">
                    <div class="user-avatar" style="width: 100px; height: 100px; font-size: 40px; margin: 0 auto 20px;">
                        A
                    </div>
                    <h3 style="margin-bottom: 10px;">${currentAdmin}</h3>
                    <p class="text-muted">Administrator</p>
                    <div style="margin-top: 30px; padding-top: 30px; border-top: 2px solid var(--border);">
                        <p><i class="fas fa-shield-alt"></i> Full system access</p>
                        <p><i class="fas fa-users"></i> Manage students and exams</p>
                        <p><i class="fas fa-chart-bar"></i> View all results</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.getElementById('modals-container').innerHTML = modal;
}

function closeAllModals() {
    document.getElementById('modals-container').innerHTML = '';
}

// ============ EXAMS ============
async function loadExams() {
    try {
        const response = await fetch(`${API_URL}/api/admin/exams`);
        const exams = await response.json();
        
        document.getElementById('total-exams-stat').textContent = exams.length;
        
        const examsList = document.getElementById('exams-list');
        
        if (exams.length === 0) {
            examsList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-book"></i></div>
                    <h3 class="empty-title">No Exams Yet</h3>
                    <p class="empty-text">Create your first exam to get started</p>
                </div>
            `;
            return;
        }
        
        examsList.innerHTML = exams.map(exam => `
            <div class="exam-card" style="cursor: default;">
                <div class="exam-icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <h3>${exam.title}</h3>
                <p>${exam.questions.length} questions</p>
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button class="btn btn-sm btn-primary" onclick="editExam(${exam.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteExam(${exam.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading exams:', error);
    }
}

function showCreateExam() {
    currentExam = null;
    questions = [];
    
    const modal = `
        <div class="modal" onclick="if(event.target===this) closeAllModals()">
            <div class="modal-content" style="max-width: 800px;">
                <div class="modal-header">
                    <h2 class="modal-title"><i class="fas fa-plus"></i> Create New Exam</h2>
                    <button class="modal-close" onclick="closeAllModals()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="form-group">
                    <label class="form-label">Exam Title</label>
                    <input type="text" id="exam-title" class="form-control" placeholder="Enter exam title" required>
                </div>
                <h3 style="margin: 30px 0 20px;"><i class="fas fa-question-circle"></i> Questions</h3>
                <div id="questions-list"></div>
                <button class="btn btn-secondary" onclick="addQuestion()">
                    <i class="fas fa-plus"></i> Add Question
                </button>
                <div style="display: flex; gap: 10px; margin-top: 30px;">
                    <button class="btn btn-primary" onclick="saveExam()">
                        <i class="fas fa-save"></i> Save Exam
                    </button>
                    <button class="btn btn-secondary" onclick="closeAllModals()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </div>
        </div>
    `;
    document.getElementById('modals-container').innerHTML = modal;
}

async function editExam(examId) {
    try {
        const response = await fetch(`${API_URL}/api/admin/exams`);
        const exams = await response.json();
        currentExam = exams.find(e => e.id === examId);
        
        if (currentExam) {
            questions = [...currentExam.questions];
            showCreateExam();
            document.getElementById('exam-title').value = currentExam.title;
            renderQuestions();
        }
    } catch (error) {
        console.error('Error loading exam:', error);
    }
}

async function deleteExam(examId) {
    if (!confirm('Are you sure you want to delete this exam?')) return;
    
    try {
        await fetch(`${API_URL}/api/admin/exams/${examId}`, { method: 'DELETE' });
        loadExams();
    } catch (error) {
        console.error('Error deleting exam:', error);
    }
}

async function saveExam() {
    const title = document.getElementById('exam-title').value;
    
    if (!title) {
        alert('Please enter exam title');
        return;
    }
    
    if (questions.length === 0) {
        alert('Please add at least one question');
        return;
    }
    
    try {
        if (currentExam) {
            await fetch(`${API_URL}/api/admin/exams/${currentExam.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title })
            });
            
            for (const q of currentExam.questions) {
                await fetch(`${API_URL}/api/admin/exams/${currentExam.id}/questions/${q.id}`, {
                    method: 'DELETE'
                });
            }
            
            for (const q of questions) {
                await fetch(`${API_URL}/api/admin/exams/${currentExam.id}/questions`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(q)
                });
            }
        } else {
            const examResponse = await fetch(`${API_URL}/api/admin/exams`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title })
            });
            
            const examResult = await examResponse.json();
            const newExamId = examResult.exam.id;
            
            for (const q of questions) {
                await fetch(`${API_URL}/api/admin/exams/${newExamId}/questions`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(q)
                });
            }
        }
        
        closeAllModals();
        loadExams();
    } catch (error) {
        console.error('Error saving exam:', error);
        alert('Failed to save exam');
    }
}

// ============ QUESTIONS ============
function addQuestion() {
    questions.push({
        question: '',
        options: ['', '', '', ''],
        correct: 0
    });
    renderQuestions();
}

function renderQuestions() {
    const questionsList = document.getElementById('questions-list');
    questionsList.innerHTML = questions.map((q, idx) => `
        <div class="question-card" style="margin-bottom: 20px;">
            <label class="form-label">Question ${idx + 1}</label>
            <input type="text" value="${q.question}" onchange="updateQuestion(${idx}, 'question', this.value)" 
                   class="form-control" placeholder="Enter question" style="margin-bottom: 15px;">
            
            <label class="form-label">Options (select correct answer):</label>
            ${q.options.map((opt, optIdx) => `
                <div style="display: flex; gap: 10px; margin-bottom: 10px; align-items: center;">
                    <input type="radio" name="correct-${idx}" ${q.correct === optIdx ? 'checked' : ''} 
                           onchange="updateQuestion(${idx}, 'correct', ${optIdx})" style="width: auto;">
                    <input type="text" value="${opt}" onchange="updateOption(${idx}, ${optIdx}, this.value)" 
                           class="form-control" placeholder="Option ${optIdx + 1}">
                </div>
            `).join('')}
            
            <button class="btn btn-sm btn-danger" onclick="removeQuestion(${idx})" style="margin-top: 10px;">
                <i class="fas fa-trash"></i> Remove Question
            </button>
        </div>
    `).join('');
}

function updateQuestion(idx, field, value) {
    questions[idx][field] = value;
}

function updateOption(qIdx, optIdx, value) {
    questions[qIdx].options[optIdx] = value;
}

function removeQuestion(idx) {
    questions.splice(idx, 1);
    renderQuestions();
}

// ============ STUDENTS ============
async function loadStudents() {
    try {
        const response = await fetch(`${API_URL}/api/admin/students`);
        const students = await response.json();
        
        document.getElementById('total-students-stat').textContent = students.length;
        
        const studentsList = document.getElementById('students-list');
        
        if (students.length === 0) {
            studentsList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-users"></i></div>
                    <h3 class="empty-title">No Students Yet</h3>
                    <p class="empty-text">Add students to get started</p>
                </div>
            `;
            return;
        }
        
        studentsList.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th><i class="fas fa-user"></i> Name</th>
                        <th><i class="fas fa-envelope"></i> Email</th>
                        <th><i class="fas fa-calendar"></i> Joined</th>
                        <th><i class="fas fa-toggle-on"></i> Status</th>
                        <th><i class="fas fa-cog"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${students.map(student => `
                        <tr>
                            <td><strong>${student.full_name}</strong></td>
                            <td>${student.email}</td>
                            <td>${new Date(student.created_at).toLocaleDateString()}</td>
                            <td>
                                <span class="badge ${student.is_active ? 'badge-success' : 'badge-danger'}">
                                    <i class="fas fa-circle"></i> ${student.is_active ? 'Active' : 'Inactive'}
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm ${student.is_active ? 'btn-secondary' : 'btn-success'}" 
                                        onclick="toggleStudentStatus(${student.id}, ${!student.is_active})">
                                    <i class="fas fa-${student.is_active ? 'ban' : 'check'}"></i>
                                </button>
                                <button class="btn btn-sm btn-primary" onclick="resetStudentPassword(${student.id})">
                                    <i class="fas fa-key"></i>
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteStudent(${student.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

function showCreateStudent() {
    const modal = `
        <div class="modal" onclick="if(event.target===this) closeAllModals()">
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2 class="modal-title"><i class="fas fa-user-plus"></i> Add New Student</h2>
                    <button class="modal-close" onclick="closeAllModals()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" id="student-name" class="form-control" placeholder="Enter full name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" id="student-email" class="form-control" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" id="student-password" class="form-control" placeholder="Default: student123">
                </div>
                <div style="display: flex; gap: 10px;">
                    <button class="btn btn-primary" onclick="saveStudent()">
                        <i class="fas fa-save"></i> Save Student
                    </button>
                    <button class="btn btn-secondary" onclick="closeAllModals()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
                <div id="student-message" class="mt-20"></div>
            </div>
        </div>
    `;
    document.getElementById('modals-container').innerHTML = modal;
}

async function saveStudent() {
    const full_name = document.getElementById('student-name').value;
    const email = document.getElementById('student-email').value;
    const password = document.getElementById('student-password').value || 'student123';
    const messageDiv = document.getElementById('student-message');
    
    if (!full_name || !email) {
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Name and email are required</p>';
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/admin/students`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, full_name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Student added successfully!</p>';
            setTimeout(() => {
                closeAllModals();
                loadStudents();
            }, 1000);
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Error saving student:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Failed to save student</p>';
    }
}

async function toggleStudentStatus(studentId, isActive) {
    try {
        await fetch(`${API_URL}/api/admin/students/${studentId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ is_active: isActive })
        });
        loadStudents();
    } catch (error) {
        console.error('Error updating student status:', error);
    }
}

async function deleteStudent(studentId) {
    if (!confirm('Are you sure you want to delete this student?')) return;
    
    try {
        await fetch(`${API_URL}/api/admin/students/${studentId}`, { method: 'DELETE' });
        loadStudents();
    } catch (error) {
        console.error('Error deleting student:', error);
    }
}

async function resetStudentPassword(studentId) {
    const newPassword = prompt('Enter new password for student:', 'student123');
    if (!newPassword) return;
    
    try {
        const response = await fetch(`${API_URL}/api/admin/students/${studentId}/reset-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ new_password: newPassword })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Password reset successfully!');
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        alert('Failed to reset password');
    }
}

// ============ RESULTS ============
async function loadResults() {
    try {
        const response = await fetch(`${API_URL}/api/admin/results`);
        const results = await response.json();
        
        document.getElementById('total-results-stat').textContent = results.length;
        
        const resultsList = document.getElementById('results-list');
        
        if (results.length === 0) {
            resultsList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-chart-bar"></i></div>
                    <h3 class="empty-title">No Results Yet</h3>
                    <p class="empty-text">Results will appear here when students complete exams</p>
                </div>
            `;
            return;
        }
        
        resultsList.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th><i class="fas fa-book"></i> Exam</th>
                        <th><i class="fas fa-user"></i> Student</th>
                        <th><i class="fas fa-calendar"></i> Date</th>
                        <th><i class="fas fa-star"></i> Score</th>
                        <th><i class="fas fa-percentage"></i> Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    ${results.map(result => {
                        const percentage = Math.round((result.score / result.total) * 100);
                        const badgeClass = percentage >= 70 ? 'badge-success' : percentage >= 50 ? 'badge-primary' : 'badge-danger';
                        return `
                            <tr>
                                <td><strong>${result.exam_title}</strong></td>
                                <td>${result.student_name || 'Anonymous'}<br><small class="text-muted">${result.student_email || 'N/A'}</small></td>
                                <td>${result.timestamp ? new Date(result.timestamp).toLocaleDateString() : 'N/A'}</td>
                                <td>${result.score} / ${result.total}</td>
                                <td><span class="badge ${badgeClass}">${percentage}%</span></td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Error loading results:', error);
    }
}
