import pymysql
import os
from contextlib import contextmanager

# RDS Configuration
DB_CONFIG = {
    'host': os.environ.get('DB_HOST', 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com'),
    'user': os.environ.get('DB_USER', 'admin'),
    'password': os.environ.get('DB_PASSWORD', ''),  # Set via environment variable
    'database': os.environ.get('DB_NAME', 'examportal'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

@contextmanager
def get_db_connection():
    """Context manager for database connections"""
    connection = pymysql.connect(**DB_CONFIG)
    try:
        yield connection
        connection.commit()
    except Exception as e:
        connection.rollback()
        raise e
    finally:
        connection.close()

def init_database():
    """Initialize database tables"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # Create database if not exists
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']}")
            cursor.execute(f"USE {DB_CONFIG['database']}")
            
            # Admin users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS admin_users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Exams table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS exams (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            """)
            
            # Questions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS questions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    exam_id INT NOT NULL,
                    question TEXT NOT NULL,
                    option1 VARCHAR(255) NOT NULL,
                    option2 VARCHAR(255) NOT NULL,
                    option3 VARCHAR(255) NOT NULL,
                    option4 VARCHAR(255) NOT NULL,
                    correct_option INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
                )
            """)
            
            # Results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS results (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    exam_id INT NOT NULL,
                    student_id INT,
                    score INT NOT NULL,
                    total INT NOT NULL,
                    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
                )
            """)
            
            # Students table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS students (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    full_name VARCHAR(255) NOT NULL,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Insert default admin user if not exists
            cursor.execute("SELECT COUNT(*) as count FROM admin_users WHERE username = 'admin'")
            if cursor.fetchone()['count'] == 0:
                cursor.execute(
                    "INSERT INTO admin_users (username, password) VALUES (%s, %s)",
                    ('admin', 'admin123')  # In production, use hashed passwords
                )
            
            # Insert sample exam if no exams exist
            cursor.execute("SELECT COUNT(*) as count FROM exams")
            if cursor.fetchone()['count'] == 0:
                cursor.execute("INSERT INTO exams (title) VALUES (%s)", ('Python Basics',))
                exam_id = cursor.lastrowid
                
                cursor.execute("""
                    INSERT INTO questions (exam_id, question, option1, option2, option3, option4, correct_option)
                    VALUES 
                    (%s, %s, %s, %s, %s, %s, %s),
                    (%s, %s, %s, %s, %s, %s, %s)
                """, (
                    exam_id, 'What is Python?', 'A snake', 'A programming language', 'A framework', 'A database', 1,
                    exam_id, 'What is a list in Python?', 'A data structure', 'A function', 'A class', 'A module', 0
                ))
            
            conn.commit()
            print("Database initialized successfully!")
    except Exception as e:
        print(f"Database initialization warning: {e}")
        # Don't fail the app if database is already initialized

# Database operations
class DB:
    @staticmethod
    def verify_admin(username, password):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM admin_users WHERE username = %s AND password = %s",
                (username, password)
            )
            return cursor.fetchone()
    
    @staticmethod
    def get_all_exams():
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, title FROM exams ORDER BY created_at DESC")
            return cursor.fetchall()
    
    @staticmethod
    def get_exam_with_questions(exam_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM exams WHERE id = %s", (exam_id,))
            exam = cursor.fetchone()
            
            if exam:
                cursor.execute(
                    "SELECT id, question, option1, option2, option3, option4, correct_option FROM questions WHERE exam_id = %s",
                    (exam_id,)
                )
                questions = cursor.fetchall()
                
                exam['questions'] = [
                    {
                        'id': q['id'],
                        'question': q['question'],
                        'options': [q['option1'], q['option2'], q['option3'], q['option4']],
                        'correct': q['correct_option']
                    }
                    for q in questions
                ]
            
            return exam
    
    @staticmethod
    def create_exam(title):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO exams (title) VALUES (%s)", (title,))
            return cursor.lastrowid
    
    @staticmethod
    def update_exam(exam_id, title):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE exams SET title = %s WHERE id = %s", (title, exam_id))
            return cursor.rowcount > 0
    
    @staticmethod
    def delete_exam(exam_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM exams WHERE id = %s", (exam_id,))
            return cursor.rowcount > 0
    
    @staticmethod
    def add_question(exam_id, question, options, correct):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO questions (exam_id, question, option1, option2, option3, option4, correct_option)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (exam_id, question, options[0], options[1], options[2], options[3], correct)
            )
            return cursor.lastrowid
    
    @staticmethod
    def delete_question(question_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM questions WHERE id = %s", (question_id,))
            return cursor.rowcount > 0
    
    @staticmethod
    def delete_exam_questions(exam_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM questions WHERE exam_id = %s", (exam_id,))
            return cursor.rowcount
    
    @staticmethod
    def save_result(exam_id, score, total):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO results (exam_id, score, total) VALUES (%s, %s, %s)",
                (exam_id, score, total)
            )
            return cursor.lastrowid
    
    @staticmethod
    def get_all_results():
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT r.id, r.exam_id, e.title as exam_title, r.score, r.total, r.submitted_at
                FROM results r
                JOIN exams e ON r.exam_id = e.id
                ORDER BY r.submitted_at DESC
            """)
            return cursor.fetchall()
    
    # Student Management
    @staticmethod
    def create_student(email, password, full_name):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO students (email, password, full_name) VALUES (%s, %s, %s)",
                (email, password, full_name)
            )
            return cursor.lastrowid
    
    @staticmethod
    def get_student_by_email(email):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM students WHERE email = %s", (email,))
            return cursor.fetchone()
    
    @staticmethod
    def verify_student(email, password):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM students WHERE email = %s AND password = %s AND is_active = 1",
                (email, password)
            )
            return cursor.fetchone()
    
    @staticmethod
    def get_all_students():
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, email, full_name, is_active, created_at 
                FROM students 
                ORDER BY created_at DESC
            """)
            return cursor.fetchall()
    
    @staticmethod
    def update_student_status(student_id, is_active):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE students SET is_active = %s WHERE id = %s",
                (is_active, student_id)
            )
            return cursor.rowcount > 0
    
    @staticmethod
    def delete_student(student_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM students WHERE id = %s", (student_id,))
            return cursor.rowcount > 0
    
    @staticmethod
    def update_student_password(student_id, new_password):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE students SET password = %s WHERE id = %s",
                (new_password, student_id)
            )
            return cursor.rowcount > 0
    
    @staticmethod
    def save_result_with_student(exam_id, student_id, score, total):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Check if student_id column exists
            cursor.execute("SHOW COLUMNS FROM results LIKE 'student_id'")
            has_student_id = cursor.fetchone() is not None
            
            if has_student_id:
                cursor.execute(
                    "INSERT INTO results (exam_id, student_id, score, total) VALUES (%s, %s, %s, %s)",
                    (exam_id, student_id, score, total)
                )
            else:
                cursor.execute(
                    "INSERT INTO results (exam_id, score, total) VALUES (%s, %s, %s)",
                    (exam_id, score, total)
                )
            return cursor.lastrowid
    
    @staticmethod
    def get_student_results(student_id):
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Check if student_id column exists
            cursor.execute("SHOW COLUMNS FROM results LIKE 'student_id'")
            has_student_id = cursor.fetchone() is not None
            
            if has_student_id:
                cursor.execute("""
                    SELECT r.id, r.exam_id, e.title as exam_title, r.score, r.total, r.submitted_at
                    FROM results r
                    JOIN exams e ON r.exam_id = e.id
                    WHERE r.student_id = %s
                    ORDER BY r.submitted_at DESC
                """, (student_id,))
            else:
                # Return empty if column doesn't exist
                return []
            
            return cursor.fetchall()
    
    @staticmethod
    def get_all_results_with_students():
        with get_db_connection() as conn:
            cursor = conn.cursor()
            # Check if student_id column exists
            cursor.execute("SHOW COLUMNS FROM results LIKE 'student_id'")
            has_student_id = cursor.fetchone() is not None
            
            if has_student_id:
                cursor.execute("""
                    SELECT r.id, r.exam_id, e.title as exam_title, 
                           s.email as student_email, s.full_name as student_name,
                           r.score, r.total, r.submitted_at
                    FROM results r
                    JOIN exams e ON r.exam_id = e.id
                    LEFT JOIN students s ON r.student_id = s.id
                    ORDER BY r.submitted_at DESC
                """)
            else:
                cursor.execute("""
                    SELECT r.id, r.exam_id, e.title as exam_title, 
                           NULL as student_email, NULL as student_name,
                           r.score, r.total, r.submitted_at
                    FROM results r
                    JOIN exams e ON r.exam_id = e.id
                    ORDER BY r.submitted_at DESC
                """)
            
            return cursor.fetchall()
