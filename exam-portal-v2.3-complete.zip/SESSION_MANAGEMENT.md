# Session Management & Authentication

## Overview

The exam portal now uses JWT (JSON Web Token) based session management for secure authentication and authorization. This replaces the previous localStorage-only approach with a more secure token-based system.

## Features

### 🔐 Security Features
- **JWT Tokens**: Secure token-based authentication
- **Token Expiration**: Automatic session timeout
  - Students: 24 hours
  - Admins: 8 hours
- **Token Refresh**: Automatic token renewal
- **Secure Headers**: Authorization via Bearer tokens
- **Protected Routes**: Backend endpoints require valid tokens

### 🎯 User Experience
- **Auto-Login**: Seamless authentication after registration
- **Session Persistence**: Stay logged in across page refreshes
- **Auto-Refresh**: Tokens refresh automatically every 30 minutes
- **Graceful Logout**: Clean session termination
- **Error Handling**: Automatic redirect on auth failures

## Architecture

### Backend Components

#### 1. Session Manager (`backend/session_manager.py`)
```python
# Generate token
token = SessionManager.generate_token(
    user_id=user_id,
    user_type='student',  # or 'admin'
    username=username,
    email=email,
    full_name=full_name
)

# Verify token
payload = SessionManager.verify_token(token)

# Refresh token
new_token = SessionManager.refresh_token(old_token)
```

#### 2. Authentication Decorators
```python
# Require authentication
@app.route('/api/protected')
@require_auth('student')  # or 'admin' or None for any
def protected_route():
    user = request.current_user
    return jsonify(user)

# Optional authentication
@app.route('/api/public')
@optional_auth()
def public_route():
    user = request.current_user  # None if not authenticated
    return jsonify(user)
```

### Frontend Components

#### 1. Session Manager (`frontend/session-manager.js`)
```javascript
// Store session
sessionManager.setSession(token, userData);

// Get token
const token = sessionManager.getToken();

// Get user data
const user = sessionManager.getUserData();

// Check authentication
if (sessionManager.isAuthenticated()) {
    // User is logged in
}

// Make authenticated request
const response = await sessionManager.authenticatedFetch(url, options);

// Logout
await sessionManager.logout();
```

## API Endpoints

### Authentication Endpoints

#### Admin Login
```http
POST /api/admin/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "username": "admin",
    "admin_id": 1,
    "is_root": true
  }
}
```

#### Student Login
```http
POST /api/student/login
Content-Type: application/json

{
  "email": "student@example.com",
  "password": "password123"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "student": {
    "id": 1,
    "username": "student1",
    "email": "student@example.com",
    "full_name": "John Doe"
  }
}
```

#### Student Registration
```http
POST /api/student/register
Content-Type: application/json

{
  "email": "new@example.com",
  "password": "password123",
  "full_name": "Jane Doe",
  "username": "jane"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "student": {
    "id": 2,
    "username": "jane",
    "email": "new@example.com",
    "full_name": "Jane Doe"
  }
}
```

### Session Management Endpoints

#### Verify Token
```http
POST /api/auth/verify
Content-Type: application/json

{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}

Response:
{
  "valid": true,
  "user": {
    "user_id": 1,
    "user_type": "student",
    "username": "student1",
    "email": "student@example.com",
    "full_name": "John Doe"
  }
}
```

#### Refresh Token
```http
POST /api/auth/refresh
Content-Type: application/json

{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

#### Logout
```http
POST /api/auth/logout
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

Response:
{
  "success": true,
  "message": "Logged out successfully"
}
```

## Token Structure

### JWT Payload
```json
{
  "user_id": 1,
  "user_type": "student",
  "username": "student1",
  "email": "student@example.com",
  "full_name": "John Doe",
  "is_root": false,
  "exp": 1703721600,
  "iat": 1703635200
}
```

### Token Fields
- `user_id`: User's database ID
- `user_type`: "student" or "admin"
- `username`: User's username
- `email`: User's email (students only)
- `full_name`: User's full name (students only)
- `is_root`: Root admin flag (admins only)
- `exp`: Expiration timestamp
- `iat`: Issued at timestamp

## Implementation Guide

### Backend Integration

#### 1. Update Requirements
```bash
pip install PyJWT==2.8.0 python-dotenv==1.0.0
```

#### 2. Set Environment Variable
```bash
# In production, set a strong secret key
export JWT_SECRET_KEY="your-super-secret-key-change-this"
```

#### 3. Protect Routes
```python
from session_manager import require_auth

@app.route('/api/student/profile')
@require_auth('student')
def get_profile():
    user = request.current_user
    return jsonify(user)
```

### Frontend Integration

#### 1. Include Session Manager
```html
<script src="session-manager.js"></script>
```

#### 2. Update Login Handler
```javascript
// Old way
localStorage.setItem('student', JSON.stringify(data));

// New way
const response = await fetch(`${API_URL}/api/student/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
});

const result = await response.json();

if (result.success) {
    sessionManager.setSession(result.token, result.student);
    window.location.href = 'student-dashboard.html';
}
```

#### 3. Check Authentication
```javascript
// On page load
if (!sessionManager.isAuthenticated()) {
    window.location.href = 'student-auth.html';
}

// Verify token is still valid
const valid = await sessionManager.verifyToken();
if (!valid) {
    window.location.href = 'student-auth.html';
}
```

#### 4. Make Authenticated Requests
```javascript
// Old way
const response = await fetch(`${API_URL}/api/exams`);

// New way
const response = await sessionManager.authenticatedFetch(
    `${API_URL}/api/exams`
);
```

#### 5. Logout
```javascript
// Old way
localStorage.removeItem('student');

// New way
await sessionManager.logout();
window.location.href = 'student-auth.html';
```

## Security Best Practices

### Backend
1. **Secret Key**: Use strong, random secret key in production
2. **HTTPS Only**: Always use HTTPS in production
3. **Token Expiration**: Set appropriate expiration times
4. **Validate Tokens**: Always verify tokens on protected routes
5. **Rate Limiting**: Implement rate limiting on auth endpoints

### Frontend
1. **Secure Storage**: Tokens stored in localStorage (consider httpOnly cookies for production)
2. **Auto-Refresh**: Tokens refresh automatically before expiration
3. **Error Handling**: Graceful handling of auth errors
4. **Logout**: Always clear tokens on logout
5. **HTTPS**: Use HTTPS to prevent token interception

## Migration from Old System

### Automatic Migration
The session manager automatically detects and clears old localStorage data:
- Old `student` key → Cleared, user must re-login
- Old `admin` key → Cleared, user must re-login

### Manual Migration Steps
1. Deploy backend with session management
2. Deploy frontend with session manager
3. Users will be logged out automatically
4. Users login again to get new JWT tokens

## Troubleshooting

### Token Expired
**Symptom**: User gets logged out unexpectedly  
**Solution**: Token expired, user needs to login again

### Invalid Token
**Symptom**: API returns 401 Unauthorized  
**Solution**: Token is invalid or corrupted, clear session and login again

### Token Not Sent
**Symptom**: API returns "No authorization token provided"  
**Solution**: Ensure `Authorization: Bearer <token>` header is sent

### Auto-Refresh Fails
**Symptom**: Token refresh returns error  
**Solution**: Token is too old or invalid, user needs to login again

## Testing

### Test Token Generation
```bash
curl -X POST https://api.venkatgh.people.aws.dev/api/student/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Test Token Verification
```bash
curl -X POST https://api.venkatgh.people.aws.dev/api/auth/verify \
  -H "Content-Type: application/json" \
  -d '{"token":"YOUR_TOKEN_HERE"}'
```

### Test Protected Endpoint
```bash
curl https://api.venkatgh.people.aws.dev/api/student/profile \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Future Enhancements

1. **Refresh Tokens**: Separate refresh tokens for better security
2. **Token Blacklist**: Invalidate tokens on logout
3. **Multi-Device**: Track active sessions per user
4. **Session History**: Log login/logout events
5. **2FA**: Two-factor authentication
6. **OAuth**: Social login integration
7. **Remember Me**: Extended session duration option
8. **httpOnly Cookies**: More secure token storage

## Version History

- **v2.3** (Dec 2025): Initial JWT session management implementation
  - JWT token generation and verification
  - Token refresh mechanism
  - Protected route decorators
  - Frontend session manager
  - Auto-refresh every 30 minutes
  - Graceful error handling

## Support

For issues or questions:
- Check browser console for errors
- Verify token in localStorage
- Check backend logs for auth errors
- Ensure HTTPS is used
- Verify secret key is set
