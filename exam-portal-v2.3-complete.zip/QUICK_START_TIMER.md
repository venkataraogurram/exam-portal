# Timer Feature - Quick Start Guide

## 🚀 Deploy in 3 Steps

### Step 1: Database (5 minutes)
```bash
# SSH to EC2
ssh ec2-user@<your-ec2-ip>

# Run migration
python3 add_duration_to_exams.py
```

### Step 2: Backend (3 minutes)
```bash
cd backend
eb deploy exam-backend-alb
```

### Step 3: Frontend (3 minutes)
```bash
cd frontend
eb deploy exam-frontend-alb
```

## ✅ Quick Test

### Admin Test (2 minutes)
1. Open: https://exam.venkatgh.people.aws.dev/admin.html
2. Login: `admin` / `admin123`
3. Create exam with 5-minute duration
4. Verify duration shows in exam card

### Student Test (3 minutes)
1. Open: https://exam.venkatgh.people.aws.dev/student-auth.html
2. Login as student
3. Start exam
4. Verify timer counts down

## 📋 What Changed

### Database
- Added `duration` column to `exams` table

### Admin Console
- Duration field in exam creation/edit forms
- Duration displayed in exam cards

### Student Dashboard
- Timer in exam header
- Color warnings (purple → orange → red)
- Auto-submit at 00:00

## 🎯 Key Features

| Feature | Description |
|---------|-------------|
| **Duration** | Set exam time limit (default: 30 min) |
| **Timer** | Visual countdown in MM:SS format |
| **Warnings** | Orange at 5 min, red at 1 min |
| **Alerts** | Notifications at 5 min and 1 min |
| **Auto-Submit** | Submits exam when time expires |
| **Pulse** | Animation when time is critical |

## 🐛 Troubleshooting

### Timer not appearing?
- Clear browser cache
- Check console for errors
- Verify API returns duration

### Duration not saving?
- Check database column exists
- Verify backend receives duration
- Check browser console

### Timer not counting?
- Check JavaScript errors
- Verify startTimer() is called
- Try different browser

## 📚 Documentation

- **TIMER_FEATURE.md** - Complete feature docs
- **DEPLOY_TIMER_FEATURE.md** - Detailed deployment
- **RELEASE_NOTES_V2.2.md** - Release notes
- **TIMER_IMPLEMENTATION_SUMMARY.md** - Implementation details

## 🆘 Need Help?

1. Check browser console for errors
2. Review deployment logs
3. Verify database schema
4. Read detailed documentation

## 🎉 Success Criteria

- [ ] Database has duration column
- [ ] Admin can set exam duration
- [ ] Duration displays in admin console
- [ ] Timer appears in student exam
- [ ] Timer counts down correctly
- [ ] Color changes at 5 min and 1 min
- [ ] Auto-submit works at 00:00

---

**Total Deployment Time**: ~15 minutes  
**Version**: 2.2  
**Status**: Ready for Production ✅
