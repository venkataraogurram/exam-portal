#!/usr/bin/env python3
"""
Test database connectivity for Exam Portal
Run this on the Beanstalk instance to verify RDS connection
"""

import pymysql
import sys

DB_CONFIG = {
    'host': 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'Admin123',
    'database': 'examportal',
    'port': 3306,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def test_connection():
    print("Testing database connection...")
    print(f"Host: {DB_CONFIG['host']}")
    print(f"Database: {DB_CONFIG['database']}")
    print(f"User: {DB_CONFIG['user']}")
    print()
    
    try:
        # Test connection
        print("Connecting to database...")
        connection = pymysql.connect(**DB_CONFIG)
        print("✓ Connection successful!")
        
        # Test query
        print("\nTesting query...")
        cursor = connection.cursor()
        cursor.execute("SELECT VERSION()")
        version = cursor.fetchone()
        print(f"✓ MySQL version: {version['VERSION()']}")
        
        # Check tables
        print("\nChecking tables...")
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        print(f"✓ Found {len(tables)} tables:")
        for table in tables:
            table_name = list(table.values())[0]
            cursor.execute(f"SELECT COUNT(*) as count FROM {table_name}")
            count = cursor.fetchone()['count']
            print(f"  - {table_name}: {count} rows")
        
        # Check admin users
        print("\nChecking admin users...")
        cursor.execute("SELECT id, username FROM admin_users")
        admins = cursor.fetchall()
        print(f"✓ Found {len(admins)} admin(s):")
        for admin in admins:
            print(f"  - ID {admin['id']}: {admin['username']}")
        
        connection.close()
        print("\n✓ All tests passed!")
        return True
        
    except pymysql.Error as e:
        print(f"\n✗ Database error: {e}")
        print(f"Error code: {e.args[0]}")
        print(f"Error message: {e.args[1]}")
        return False
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        return False

if __name__ == '__main__':
    success = test_connection()
    sys.exit(0 if success else 1)
