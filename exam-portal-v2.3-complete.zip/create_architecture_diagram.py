#!/usr/bin/env python3
"""
Generate AWS Architecture Diagram for Exam Portal
Requires: pip install diagrams
"""

from diagrams import Diagram, Cluster, Edge
from diagrams.aws.network import Route53, ALB
from diagrams.aws.compute import ElasticBeanstalk, EC2
from diagrams.aws.database import RDS
from diagrams.aws.security import CertificateManager
from diagrams.aws.management import Cloudwatch
from diagrams.aws.storage import S3
from diagrams.onprem.client import Users

# Create diagram
with Diagram("Exam Portal - AWS Architecture", 
             filename="architecture", 
             show=False,
             direction="TB",
             graph_attr={
                 "fontsize": "20",
                 "bgcolor": "white",
                 "pad": "0.5",
                 "splines": "ortho"
             }):
    
    # Users
    users = Users("Internet Users\n(Students, Admins, Mobile)")
    
    # DNS and Security Layer
    with Cluster("DNS & Security Layer"):
        dns = Route53("Amazon Route 53\nDNS Management\n\nexam.venkatgh.people.aws.dev\napi.venkatgh.people.aws.dev")
        cert = CertificateManager("AWS Certificate Manager\nSSL/TLS Certificates\n\n*.venkatgh.people.aws.dev")
    
    # Frontend Cluster
    with Cluster("Frontend Layer"):
        with Cluster("exam-frontend-env"):
            alb_frontend = ALB("Application Load Balancer\nHTTPS:443")
            with Cluster("Auto Scaling Group"):
                eb_frontend = ElasticBeanstalk("Elastic Beanstalk")
                ec2_frontend = [
                    EC2("EC2 Instance\nNginx\nStatic Files"),
                ]
    
    # Backend Cluster
    with Cluster("Backend Layer"):
        with Cluster("exam-backend-alb"):
            alb_backend = ALB("Application Load Balancer\nHTTPS:443")
            with Cluster("Auto Scaling Group"):
                eb_backend = ElasticBeanstalk("Elastic Beanstalk")
                ec2_backend = [
                    EC2("EC2 Instance\nPython 3.11\nFlask API\nGunicorn"),
                ]
    
    # Database Layer
    with Cluster("Database Layer"):
        rds = RDS("Amazon RDS MySQL\nvenkat-rds\n\nDatabase: examportal\nTables: admin_users, students,\nexams, questions, results,\nexam_assignments")
    
    # Supporting Services
    with Cluster("Supporting Services"):
        cloudwatch = Cloudwatch("CloudWatch\nLogs & Metrics")
        s3 = S3("Amazon S3\nApplication Versions")
    
    # Main flow connections
    users >> Edge(label="HTTPS", color="darkgreen", style="bold") >> dns
    dns >> Edge(label="DNS Resolution") >> cert
    
    # Frontend flow
    cert >> Edge(label="SSL/TLS") >> alb_frontend
    alb_frontend >> Edge(label="HTTP") >> eb_frontend
    eb_frontend >> ec2_frontend
    
    # Backend flow
    cert >> Edge(label="SSL/TLS") >> alb_backend
    alb_backend >> Edge(label="HTTP") >> eb_backend
    eb_backend >> ec2_backend
    
    # Database connection
    ec2_backend >> Edge(label="MySQL:3306", color="blue") >> rds
    
    # Monitoring connections
    eb_frontend >> Edge(label="Logs", style="dashed") >> cloudwatch
    eb_backend >> Edge(label="Logs", style="dashed") >> cloudwatch
    
    # Storage connections
    eb_frontend >> Edge(label="Versions", style="dashed") >> s3
    eb_backend >> Edge(label="Versions", style="dashed") >> s3

print("✓ Architecture diagram created successfully!")
print("✓ File saved as: architecture.png")
print("\nTo view the diagram:")
print("  - Open architecture.png in any image viewer")
print("  - Or add it to README.md: ![Architecture](architecture.png)")
