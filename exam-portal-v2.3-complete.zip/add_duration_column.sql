-- Add duration column to exams table if it doesn't exist
-- Run this on your RDS database

-- Check if column exists and add it if not
ALTER TABLE exams 
ADD COLUMN IF NOT EXISTS duration INT DEFAULT 30 COMMENT 'Exam duration in minutes';

-- Update existing exams to have default duration
UPDATE exams SET duration = 30 WHERE duration IS NULL;

-- Verify the change
SELECT id, title, duration FROM exams;
