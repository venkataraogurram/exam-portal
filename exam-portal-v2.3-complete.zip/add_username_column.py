#!/usr/bin/env python3
"""
Migration script to add username column to students table
"""
import pymysql
import os

DB_CONFIG = {
    'host': os.environ.get('DB_HOST', 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com'),
    'user': os.environ.get('DB_USER', 'admin'),
    'password': os.environ.get('DB_PASSWORD', 'Admin123'),
    'database': os.environ.get('DB_NAME', 'examportal'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def add_username_column():
    try:
        connection = pymysql.connect(**DB_CONFIG)
        cursor = connection.cursor()
        
        # Check if username column exists
        cursor.execute("SHOW COLUMNS FROM students LIKE 'username'")
        if cursor.fetchone():
            print("✓ Username column already exists")
        else:
            print("Adding username column...")
            cursor.execute("""
                ALTER TABLE students 
                ADD COLUMN username VARCHAR(50) UNIQUE AFTER id
            """)
            connection.commit()
            print("✓ Username column added successfully")
        
        # Generate usernames for existing students without one
        cursor.execute("SELECT id, email FROM students WHERE username IS NULL")
        students = cursor.fetchall()
        
        if students:
            print(f"Generating usernames for {len(students)} existing students...")
            for student in students:
                username = student['email'].split('@')[0]
                # Check if username already exists
                cursor.execute("SELECT id FROM students WHERE username = %s", (username,))
                if cursor.fetchone():
                    # Add number suffix if username exists
                    username = f"{username}{student['id']}"
                
                cursor.execute(
                    "UPDATE students SET username = %s WHERE id = %s",
                    (username, student['id'])
                )
            connection.commit()
            print(f"✓ Generated usernames for {len(students)} students")
        else:
            print("✓ All students already have usernames")
        
        cursor.close()
        connection.close()
        print("\n✅ Migration completed successfully!")
        
    except Exception as e:
        print(f"❌ Migration failed: {e}")

if __name__ == '__main__':
    add_username_column()
