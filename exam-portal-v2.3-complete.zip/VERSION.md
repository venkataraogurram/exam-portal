# Exam Portal - Version History

## Version 2.3 - December 27, 2025

### New Features
- **JWT Session Management**: Secure token-based authentication
  - JWT tokens with expiration (24h students, 8h admins)
  - Automatic token refresh every 30 minutes
  - Protected API endpoints with `@require_auth` decorator
  - Session verification and refresh endpoints
  - Hybrid storage (JWT + localStorage) for reliability
- **Enhanced Security**: Bearer token authorization for API calls
- **Improved UX**: Seamless authentication and session persistence

### Technical Changes
- Added `backend/session_manager.py` - JWT token management
- Added `frontend/session-manager.js` - Client-side session handling
- Updated login/registration to return JWT tokens
- Protected password change endpoint with token auth
- Fixed FontAwesome CORS issue (switched to CDN)
- Fixed duplicate API_URL declaration
- Fixed student login redirect loop

### Files Added
- `backend/session_manager.py`
- `frontend/session-manager.js`
- `SESSION_MANAGEMENT.md`
- `SESSION_IMPLEMENTATION_SUMMARY.md`
- `RELEASE_NOTES_V2.3.md`

### Dependencies Added
- `PyJWT==2.8.0` - JWT token handling
- `python-dotenv==1.0.0` - Environment variables

### Bug Fixes
- Fixed session timing issues
- Fixed authentication reliability
- Improved error handling
- Better fallback mechanisms

---

## Version 2.2 - December 27, 2025

### New Features
- **Exam Timer**: Configurable countdown timer for each exam
  - Admins can set exam duration when creating/editing exams (default: 30 minutes)
  - Visual countdown timer displayed in exam header
  - Color-coded warnings: purple (normal), orange (≤5 min), red with pulse (≤1 min)
  - Alert notifications at 5 minutes and 1 minute remaining
  - Auto-submit when time expires
  - Timer stops on manual submit or navigation

### Technical Changes
- Added `duration` column to `exams` table (INT, default 30)
- Updated backend API endpoints to handle exam duration
- Enhanced student dashboard with timer functionality
- Added pulse animation CSS for critical timer state
- Created database migration scripts

### Files Modified
- `backend/database.py` - Added duration parameter to exam functions
- `backend/app.py` - Updated exam endpoints to handle duration
- `frontend/admin.js` - Added duration field to exam creation/edit forms
- `frontend/student-dashboard.js` - Implemented timer with warnings and auto-submit
- `frontend/modern-style.css` - Added pulse animation keyframes

### New Files
- `add_duration_column.sql` - SQL migration script
- `add_duration_to_exams.py` - Python migration script with verification
- `TIMER_FEATURE.md` - Comprehensive timer feature documentation
- `DEPLOY_TIMER_FEATURE.md` - Step-by-step deployment guide

### Deployment Requirements
1. Run database migration to add duration column to exams table
2. Deploy backend with updated exam handling
3. Deploy frontend with timer functionality
4. Test timer with various durations (1 min, 5 min, 30 min, etc.)

---

## Version 2.1 - December 27, 2025

### New Features
- **Edit Student Details**: Admins can now edit student name, username, and email
- **Exam Assignment System**: Assign specific exams to selected students
- **Auto-Login After Registration**: Students automatically logged in after successful registration
- **Responsive Design**: Full mobile and tablet support
- **Portfolio Ready**: Complete documentation and architecture diagrams

### Improvements
- Enhanced student management interface
- Better validation for duplicate emails and usernames
- Improved error messages and user feedback
- Mobile-optimized UI for all pages

### Bug Fixes
- Fixed database connection issues
- Resolved CORS configuration
- Fixed JavaScript syntax errors
- Improved error handling across the application

---

## Version 2.0 - December 27, 2025

### Major Updates
- **HTTPS Support**: Full HTTPS implementation for both frontend and backend
- **Application Load Balancer**: Migrated from single instance to ALB architecture
- **Custom Domain**: exam.venkatgh.people.aws.dev and api.venkatgh.people.aws.dev
- **Database Connection Fixed**: Added DB_PASSWORD to environment configuration

### Features Added
- Username support for students (login with email or username)
- Exam import from text files
- Admin management system (root admin can manage other admins)
- Modern UI with Font Awesome icons and Inter font

---

## Version 1.0 - December 2025

### Initial Release
- Admin authentication and management
- Student registration and authentication
- Exam creation and management
- Question management with multiple choice options
- Results tracking and reporting
- Student management (add, activate/deactivate, delete, reset password)

### Architecture
- Backend: Flask API on AWS Elastic Beanstalk
- Frontend: Static HTML/CSS/JS on AWS Elastic Beanstalk
- Database: MySQL on AWS RDS
