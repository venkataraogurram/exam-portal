#!/usr/bin/env python3
"""
Script to add duration column to exams table
Run this on EC2 instance or locally with RDS access
"""

import pymysql
import sys

# Database configuration
DB_CONFIG = {
    'host': 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'Admin123',
    'database': 'examportal',
    'port': 3306
}

def add_duration_column():
    """Add duration column to exams table"""
    try:
        print("Connecting to database...")
        conn = pymysql.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("Checking if duration column exists...")
        cursor.execute("""
            SELECT COUNT(*) 
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = 'examportal' 
            AND TABLE_NAME = 'exams' 
            AND COLUMN_NAME = 'duration'
        """)
        
        exists = cursor.fetchone()[0]
        
        if exists:
            print("✓ Duration column already exists")
        else:
            print("Adding duration column...")
            cursor.execute("""
                ALTER TABLE exams 
                ADD COLUMN duration INT DEFAULT 30 COMMENT 'Exam duration in minutes'
            """)
            conn.commit()
            print("✓ Duration column added successfully")
        
        # Update any NULL values to default
        print("Updating NULL values to default (30 minutes)...")
        cursor.execute("UPDATE exams SET duration = 30 WHERE duration IS NULL")
        conn.commit()
        print(f"✓ Updated {cursor.rowcount} rows")
        
        # Verify the change
        print("\nCurrent exams with duration:")
        cursor.execute("SELECT id, title, duration FROM exams")
        exams = cursor.fetchall()
        
        if exams:
            print(f"{'ID':<5} {'Title':<40} {'Duration (min)':<15}")
            print("-" * 60)
            for exam in exams:
                print(f"{exam[0]:<5} {exam[1]:<40} {exam[2]:<15}")
        else:
            print("No exams found in database")
        
        cursor.close()
        conn.close()
        print("\n✓ Migration completed successfully!")
        return True
        
    except pymysql.Error as e:
        print(f"✗ Database error: {e}")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("Adding duration column to exams table")
    print("=" * 60)
    
    success = add_duration_column()
    sys.exit(0 if success else 1)
