# Timer Feature Deployment Guide

## Quick Deployment Steps

### Step 1: Update Database Schema (REQUIRED)

The database needs a new `duration` column in the `exams` table.

#### Option A: Using Python Script (Recommended)
```bash
# 1. SSH to EC2 backend instance
ssh ec2-user@<your-ec2-ip>

# 2. Upload the migration script
# (Use scp from your local machine)
scp add_duration_to_exams.py ec2-user@<your-ec2-ip>:/tmp/

# 3. Install pymysql if not already installed
sudo pip3 install pymysql

# 4. Run the migration
python3 /tmp/add_duration_to_exams.py
```

#### Option B: Using MySQL Client
```bash
# 1. Install MySQL client on EC2
sudo yum install mariadb105 -y

# 2. Connect to RDS
mysql -h venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com \
      -u admin -pAdmin123 -D examportal

# 3. Run SQL commands
ALTER TABLE exams ADD COLUMN duration INT DEFAULT 30;
UPDATE exams SET duration = 30 WHERE duration IS NULL;
SELECT id, title, duration FROM exams;
exit;
```

#### Option C: Using SQL File
```bash
# 1. Upload SQL file to EC2
scp add_duration_column.sql ec2-user@<your-ec2-ip>:/tmp/

# 2. Execute SQL file
mysql -h venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com \
      -u admin -pAdmin123 -D examportal < /tmp/add_duration_column.sql
```

### Step 2: Deploy Backend

```bash
# Navigate to backend directory
cd backend

# Verify changes
git status

# Deploy to Elastic Beanstalk
eb deploy exam-backend-alb

# Wait for deployment to complete (2-3 minutes)
# Check deployment status
eb status exam-backend-alb

# View logs if needed
eb logs exam-backend-alb
```

### Step 3: Deploy Frontend

```bash
# Navigate to frontend directory
cd frontend

# Verify changes
git status

# Deploy to Elastic Beanstalk
eb deploy exam-frontend-alb

# Wait for deployment to complete (2-3 minutes)
# Check deployment status
eb status exam-frontend-alb

# View logs if needed
eb logs exam-frontend-alb
```

### Step 4: Verify Deployment

#### Test Admin Console
1. Open: https://exam.venkatgh.people.aws.dev/admin.html
2. Login with: admin / admin123
3. Create a new exam:
   - Click "Create Exam"
   - Enter title: "Timer Test Exam"
   - Set duration: 5 minutes
   - Add 2-3 questions
   - Save exam
4. Verify duration shows in exam card
5. Edit the exam and change duration to 10 minutes
6. Verify duration updates

#### Test Student Dashboard
1. Open: https://exam.venkatgh.people.aws.dev/student-auth.html
2. Login or register as a student
3. Assign the test exam to your student (in admin console)
4. Start the exam
5. Verify timer appears in exam header
6. Verify timer counts down
7. Wait for timer to reach 4:55 (should show orange)
8. Wait for timer to reach 0:55 (should show red with pulse)
9. Submit exam manually or wait for auto-submit

## Detailed Verification Checklist

### Database Verification
```bash
# Connect to database
mysql -h venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com \
      -u admin -pAdmin123 -D examportal

# Check schema
DESCRIBE exams;
# Should show 'duration' column with INT type, default 30

# Check existing data
SELECT id, title, duration FROM exams;
# All exams should have duration = 30

exit;
```

### Backend API Verification
```bash
# Test exam creation with duration
curl -X POST https://api.venkatgh.people.aws.dev/api/admin/exams \
  -H "Content-Type: application/json" \
  -d '{"title":"API Test Exam","duration":45}'

# Test getting exams (should include duration)
curl https://api.venkatgh.people.aws.dev/api/exams

# Test getting specific exam
curl https://api.venkatgh.people.aws.dev/api/exams/1
```

### Frontend Verification

#### Admin Console
- [ ] Duration field appears in create exam modal
- [ ] Duration field has default value of 30
- [ ] Duration field accepts numeric input
- [ ] Duration saves when creating exam
- [ ] Duration displays in exam card
- [ ] Duration field appears in edit exam modal
- [ ] Duration updates when editing exam

#### Student Dashboard
- [ ] Timer appears when exam starts
- [ ] Timer shows correct duration
- [ ] Timer format is MM:SS
- [ ] Timer counts down every second
- [ ] Timer turns orange at 5 minutes
- [ ] Timer turns red at 1 minute
- [ ] Timer pulses when red
- [ ] Alert shows at 5 minutes
- [ ] Alert shows at 1 minute
- [ ] Exam auto-submits at 00:00
- [ ] Timer stops on manual submit

## Rollback Plan

If issues occur, you can rollback:

### Rollback Backend
```bash
cd backend
eb deploy exam-backend-alb --version <previous-version>
```

### Rollback Frontend
```bash
cd frontend
eb deploy exam-frontend-alb --version <previous-version>
```

### Remove Duration Column (if needed)
```sql
-- Only if you need to completely rollback
ALTER TABLE exams DROP COLUMN duration;
```

## Common Issues and Solutions

### Issue: Duration column doesn't exist
**Solution**: Run database migration script again
```bash
python3 add_duration_to_exams.py
```

### Issue: Timer not appearing
**Solution**: 
1. Clear browser cache
2. Check browser console for errors
3. Verify API returns duration field
4. Check student-dashboard.js loaded correctly

### Issue: Timer not counting down
**Solution**:
1. Check browser console for JavaScript errors
2. Verify `startTimer()` is called
3. Check `setInterval` is working
4. Refresh page and try again

### Issue: Duration not saving in admin console
**Solution**:
1. Check browser console for errors
2. Verify admin.js sends duration in POST request
3. Check backend receives duration parameter
4. Verify database column exists

### Issue: Existing exams don't have duration
**Solution**:
```sql
UPDATE exams SET duration = 30 WHERE duration IS NULL;
```

## Performance Considerations

- Timer uses `setInterval` which runs every second
- Minimal performance impact (< 1% CPU)
- Timer stops when exam ends to free resources
- No server-side timer needed (client-side only)

## Security Considerations

- Timer is client-side only (can be manipulated)
- Server should validate submission time if needed
- Consider adding server-side time tracking in future
- Auto-submit prevents students from continuing after time

## Monitoring

### Check Backend Logs
```bash
eb logs exam-backend-alb --stream
```

### Check Frontend Logs
```bash
eb logs exam-frontend-alb --stream
```

### Monitor Database
```sql
-- Check exam durations
SELECT id, title, duration, created_at FROM exams ORDER BY created_at DESC LIMIT 10;

-- Check if any exams have NULL duration
SELECT COUNT(*) FROM exams WHERE duration IS NULL;
```

## Post-Deployment Tasks

1. **Update Documentation**
   - Update README.md with timer feature
   - Update FEATURES.md with timer details
   - Create release notes for v2.2

2. **Notify Users**
   - Inform admins about new duration field
   - Provide guidance on setting appropriate durations
   - Explain timer behavior to students

3. **Monitor Usage**
   - Check for any errors in logs
   - Monitor student feedback
   - Track exam completion rates

4. **Create Backup**
   - Backup database after migration
   - Save deployment artifacts
   - Document any custom configurations

## Support

If you encounter issues:
1. Check this deployment guide
2. Review TIMER_FEATURE.md for feature details
3. Check browser console for errors
4. Review backend/frontend logs
5. Verify database schema

## Next Steps

After successful deployment:
1. Test with real students
2. Gather feedback on timer behavior
3. Consider adding time extensions feature
4. Plan for server-side time validation
5. Add time tracking analytics
