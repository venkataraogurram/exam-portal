/**
 * Session Manager for Frontend
 * Handles JWT token storage, validation, and API authentication
 */

// Use the API_URL from the page if already defined, otherwise set default
const SESSION_API_URL = typeof API_URL !== 'undefined' ? API_URL : 'https://api.venkatgh.people.aws.dev';

class SessionManager {
    constructor() {
        this.tokenKey = 'auth_token';
        this.userKey = 'user_data';
    }

    /**
     * Store authentication token and user data
     */
    setSession(token, userData) {
        localStorage.setItem(this.tokenKey, token);
        localStorage.setItem(this.userKey, JSON.stringify(userData));
    }

    /**
     * Get stored token
     */
    getToken() {
        return localStorage.getItem(this.tokenKey);
    }

    /**
     * Get stored user data
     */
    getUserData() {
        const data = localStorage.getItem(this.userKey);
        return data ? JSON.parse(data) : null;
    }

    /**
     * Clear session (logout)
     */
    clearSession() {
        localStorage.removeItem(this.tokenKey);
        localStorage.removeItem(this.userKey);
        // Also clear old localStorage keys for backward compatibility
        localStorage.removeItem('student');
        localStorage.removeItem('admin');
    }

    /**
     * Check if user is authenticated
     */
    isAuthenticated() {
        return !!this.getToken();
    }

    /**
     * Verify token with backend
     */
    async verifyToken() {
        const token = this.getToken();
        if (!token) return false;

        try {
            const response = await fetch(`${SESSION_API_URL}/api/auth/verify`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token })
            });

            const result = await response.json();
            
            if (result.valid) {
                // Update user data
                this.setSession(token, result.user);
                return true;
            } else {
                this.clearSession();
                return false;
            }
        } catch (error) {
            console.error('Token verification error:', error);
            return false;
        }
    }

    /**
     * Refresh token
     */
    async refreshToken() {
        const token = this.getToken();
        if (!token) return false;

        try {
            const response = await fetch(`${SESSION_API_URL}/api/auth/refresh`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token })
            });

            const result = await response.json();
            
            if (result.success) {
                const userData = this.getUserData();
                this.setSession(result.token, userData);
                return true;
            } else {
                this.clearSession();
                return false;
            }
        } catch (error) {
            console.error('Token refresh error:', error);
            return false;
        }
    }

    /**
     * Make authenticated API request
     */
    async authenticatedFetch(url, options = {}) {
        const token = this.getToken();
        
        if (!token) {
            throw new Error('No authentication token');
        }

        // Add Authorization header
        const headers = {
            ...options.headers,
            'Authorization': `Bearer ${token}`
        };

        try {
            const response = await fetch(url, { ...options, headers });

            // If unauthorized, try to refresh token once
            if (response.status === 401) {
                const refreshed = await this.refreshToken();
                
                if (refreshed) {
                    // Retry request with new token
                    const newToken = this.getToken();
                    headers['Authorization'] = `Bearer ${newToken}`;
                    return await fetch(url, { ...options, headers });
                } else {
                    // Refresh failed, redirect to login
                    this.handleAuthError();
                    throw new Error('Authentication failed');
                }
            }

            return response;
        } catch (error) {
            console.error('Authenticated fetch error:', error);
            throw error;
        }
    }

    /**
     * Handle authentication errors
     */
    handleAuthError() {
        this.clearSession();
        
        const userData = this.getUserData();
        const userType = userData?.user_type || 'student';
        
        // Redirect to appropriate login page
        if (userType === 'admin') {
            window.location.href = '/admin.html';
        } else {
            window.location.href = '/student-auth.html';
        }
    }

    /**
     * Logout user
     */
    async logout() {
        try {
            // Call backend logout endpoint
            await fetch(`${SESSION_API_URL}/api/auth/logout`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getToken()}`
                }
            });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.clearSession();
        }
    }

    /**
     * Migrate old localStorage data to new session format
     */
    migrateOldSession() {
        // Check for old student data
        const oldStudent = localStorage.getItem('student');
        if (oldStudent && !this.getToken()) {
            try {
                const studentData = JSON.parse(oldStudent);
                // Old format doesn't have token, user needs to re-login
                localStorage.removeItem('student');
                console.log('Old session format detected. Please login again.');
            } catch (e) {
                console.error('Migration error:', e);
            }
        }

        // Check for old admin data
        const oldAdmin = localStorage.getItem('admin');
        if (oldAdmin && !this.getToken()) {
            localStorage.removeItem('admin');
            console.log('Old session format detected. Please login again.');
        }
    }
}

// Create singleton instance
const sessionManager = new SessionManager();

// Migrate old sessions on load
sessionManager.migrateOldSession();

// Auto-refresh token every 30 minutes
setInterval(() => {
    if (sessionManager.isAuthenticated()) {
        sessionManager.refreshToken();
    }
}, 30 * 60 * 1000);
