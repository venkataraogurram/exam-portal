// Backend Elastic Beanstalk URL
const API_URL = 'https://api.venkatgh.people.aws.dev';

let currentStudent = null;
let currentExam = null;
let timerInterval = null;
let timeRemaining = 0;

// Check if student is logged in - use old localStorage method for reliability
const studentData = localStorage.getItem('student');
if (!studentData) {
    window.location.href = 'student-auth.html';
} else {
    currentStudent = JSON.parse(studentData);
    document.getElementById('student-name').textContent = currentStudent.full_name;
    // Set user avatar initial
    const initial = currentStudent.full_name.charAt(0).toUpperCase();
    document.getElementById('user-avatar').textContent = initial;
    loadExams();
    loadMyResults();
}

function logout() {
    localStorage.removeItem('student');
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
    if (typeof sessionManager !== 'undefined') {
        sessionManager.clearSession();
    }
    window.location.href = 'student-auth.html';
}

// Load available exams
async function loadExams() {
    try {
        const student = JSON.parse(localStorage.getItem('student'));
        const response = await fetch(`${API_URL}/api/exams?student_id=${student.id}`);
        const exams = await response.json();
        
        document.getElementById('total-exams').textContent = exams.length;
        
        const examsList = document.getElementById('exams-list');
        if (exams.length === 0) {
            examsList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <h3 class="empty-title">No Exams Available</h3>
                    <p class="empty-text">Check back later for new exams</p>
                </div>
            `;
            return;
        }
        
        examsList.innerHTML = exams.map((exam, index) => {
            const icons = ['fa-code', 'fa-database', 'fa-brain', 'fa-laptop-code', 'fa-book'];
            const icon = icons[index % icons.length];
            const duration = exam.duration || 30;
            return `
                <div class="exam-card" onclick="loadExam(${exam.id})">
                    <div class="exam-icon">
                        <i class="fas ${icon}"></i>
                    </div>
                    <h3>${exam.title}</h3>
                    <p>Click to start this exam</p>
                    <div class="exam-meta">
                        <span><i class="fas fa-clock"></i> ${duration} min</span>
                        <span><i class="fas fa-question-circle"></i> Multiple Choice</span>
                    </div>
                </div>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading exams:', error);
    }
}

// Load specific exam
async function loadExam(examId) {
    try {
        const response = await fetch(`${API_URL}/api/exams/${examId}`);
        currentExam = await response.json();
        
        // Set timer duration (default 30 minutes if not set)
        const duration = currentExam.duration || 30;
        timeRemaining = duration * 60; // Convert to seconds
        
        document.getElementById('exam-title').innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <div>
                    <i class="fas fa-pencil-alt"></i> ${currentExam.title}
                </div>
                <div id="timer" style="display: flex; align-items: center; gap: 10px; padding: 10px 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; font-size: 18px; font-weight: 600;">
                    <i class="fas fa-clock"></i>
                    <span id="timer-display">--:--</span>
                </div>
            </div>
        `;
        
        const questionsDiv = document.getElementById('questions');
        questionsDiv.innerHTML = currentExam.questions.map((q, idx) => `
            <div class="question-card">
                <h3><i class="fas fa-question-circle"></i> Question ${idx + 1}: ${q.question}</h3>
                ${q.options.map((opt, optIdx) => `
                    <label class="option-label">
                        <input type="radio" name="q${q.id}" value="${optIdx}" required>
                        <span>${opt}</span>
                    </label>
                `).join('')}
            </div>
        `).join('');
        
        document.getElementById('exams-section').classList.add('hidden');
        document.getElementById('my-results-section').classList.add('hidden');
        document.getElementById('exam-section').classList.remove('hidden');
        window.scrollTo(0, 0);
        
        // Start timer
        startTimer();
    } catch (error) {
        console.error('Error loading exam:', error);
        alert('Error loading exam');
    }
}

// Timer functions
function startTimer() {
    // Clear any existing timer
    if (timerInterval) {
        clearInterval(timerInterval);
    }
    
    updateTimerDisplay();
    
    timerInterval = setInterval(() => {
        timeRemaining--;
        updateTimerDisplay();
        
        // Warning when 5 minutes left
        if (timeRemaining === 300) {
            alert('⚠️ 5 minutes remaining!');
        }
        
        // Warning when 1 minute left
        if (timeRemaining === 60) {
            alert('⚠️ 1 minute remaining!');
        }
        
        // Time's up - auto submit
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            alert('⏰ Time\'s up! Submitting your exam...');
            document.getElementById('exam-form').dispatchEvent(new Event('submit'));
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    const display = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    const timerDisplay = document.getElementById('timer-display');
    if (timerDisplay) {
        timerDisplay.textContent = display;
        
        // Change color when time is running out
        const timerElement = document.getElementById('timer');
        if (timeRemaining <= 60) {
            timerElement.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
            timerElement.style.animation = 'pulse 1s infinite';
        } else if (timeRemaining <= 300) {
            timerElement.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
        }
    }
}

function stopTimer() {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
}

// Submit exam
document.getElementById('exam-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Stop the timer
    stopTimer();
    
    const formData = new FormData(e.target);
    const answers = {};
    
    for (let [key, value] of formData.entries()) {
        const questionId = key.substring(1);
        answers[questionId] = parseInt(value);
    }
    
    try {
        const response = await fetch(`${API_URL}/api/submit`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                exam_id: currentExam.id,
                student_id: currentStudent.id,
                answers: answers
            })
        });
        
        const result = await response.json();
        
        document.getElementById('result').innerHTML = `
            <div class="result-score">${result.score} / ${result.total}</div>
            <div class="result-percentage">${Math.round((result.score / result.total) * 100)}%</div>
            <p style="color: var(--gray); margin-top: 20px;">
                ${result.score === result.total ? 'Perfect score! Excellent work!' : 
                  result.score >= result.total * 0.7 ? 'Great job! Keep it up!' : 
                  'Keep practicing to improve your score!'}
            </p>
        `;
        
        document.getElementById('exam-section').classList.add('hidden');
        document.getElementById('result-section').classList.remove('hidden');
        window.scrollTo(0, 0);
        
        // Reload results
        loadMyResults();
    } catch (error) {
        console.error('Error submitting exam:', error);
        alert('Error submitting exam');
    }
});

function backToExams() {
    // Stop timer if running
    stopTimer();
    
    document.getElementById('exam-section').classList.add('hidden');
    document.getElementById('result-section').classList.add('hidden');
    document.getElementById('exams-section').classList.remove('hidden');
    document.getElementById('my-results-section').classList.remove('hidden');
    window.scrollTo(0, 0);
}

// Load student's results
async function loadMyResults() {
    try {
        const response = await fetch(`${API_URL}/api/student/results/${currentStudent.id}`);
        const results = await response.json();
        
        const resultsDiv = document.getElementById('my-results');
        
        // Update stats
        document.getElementById('completed-exams').textContent = results.length;
        if (results.length > 0) {
            const avgScore = results.reduce((sum, r) => sum + (r.score / r.total * 100), 0) / results.length;
            document.getElementById('avg-score').textContent = Math.round(avgScore) + '%';
        }
        
        if (results.length === 0) {
            resultsDiv.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3 class="empty-title">No Results Yet</h3>
                    <p class="empty-text">Take an exam to see your scores here!</p>
                </div>
            `;
            return;
        }
        
        resultsDiv.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th><i class="fas fa-book"></i> Exam</th>
                        <th><i class="fas fa-calendar"></i> Date</th>
                        <th><i class="fas fa-star"></i> Score</th>
                        <th><i class="fas fa-percentage"></i> Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    ${results.map(result => {
                        const percentage = Math.round((result.score / result.total) * 100);
                        const badgeClass = percentage >= 70 ? 'badge-success' : percentage >= 50 ? 'badge-primary' : 'badge-danger';
                        return `
                            <tr>
                                <td><strong>${result.exam_title}</strong></td>
                                <td>${new Date(result.timestamp).toLocaleDateString()}</td>
                                <td>${result.score} / ${result.total}</td>
                                <td><span class="badge ${badgeClass}">${percentage}%</span></td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
    } catch (error) {
        console.error('Error loading results:', error);
    }
}

// Change Password
function showChangePassword() {
    document.getElementById('password-modal').classList.remove('hidden');
}

function closePasswordModal() {
    document.getElementById('password-modal').classList.add('hidden');
    document.getElementById('password-form').reset();
    document.getElementById('password-message').innerHTML = '';
}

document.getElementById('password-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const oldPassword = document.getElementById('old-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const messageDiv = document.getElementById('password-message');
    
    if (newPassword !== confirmPassword) {
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Passwords do not match</p>';
        return;
    }
    
    try {
        // Use token if available, otherwise use old method
        const token = localStorage.getItem('auth_token');
        let response;
        
        if (token) {
            response = await fetch(`${API_URL}/api/student/change-password`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    old_password: oldPassword,
                    new_password: newPassword
                })
            });
        } else {
            // Fallback for old method
            response = await fetch(`${API_URL}/api/student/change-password`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    student_id: currentStudent.id,
                    email: currentStudent.email,
                    old_password: oldPassword,
                    new_password: newPassword
                })
            });
        }
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Password changed successfully!</p>';
            setTimeout(() => {
                closePasswordModal();
            }, 1500);
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Password change error:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Failed to change password</p>';
    }
});
