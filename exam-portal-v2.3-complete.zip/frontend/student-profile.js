const API_URL = 'https://api.venkatgh.people.aws.dev';

let currentStudent = null;

// Check if student is logged in
const studentData = localStorage.getItem('student');
if (!studentData) {
    window.location.href = 'student-auth.html';
} else {
    currentStudent = JSON.parse(studentData);
    loadProfile();
}

async function loadProfile() {
    try {
        const response = await fetch(`${API_URL}/api/student/profile/${currentStudent.id}`);
        const profile = await response.json();
        
        // Update UI
        const initial = profile.full_name.charAt(0).toUpperCase();
        document.getElementById('profile-avatar').textContent = initial;
        document.getElementById('profile-name').textContent = profile.full_name;
        document.getElementById('profile-email').textContent = profile.email;
        document.getElementById('profile-completed').textContent = profile.stats.completed_exams;
        document.getElementById('profile-avg').textContent = profile.stats.average_score + '%';
        
        // Fill form
        document.getElementById('edit-name').value = profile.full_name;
        document.getElementById('edit-email').value = profile.email;
        document.getElementById('member-since').value = new Date(profile.created_at).toLocaleDateString();
        
        if (!profile.is_active) {
            document.getElementById('profile-status').className = 'badge badge-danger';
            document.getElementById('profile-status').innerHTML = '<i class="fas fa-times-circle"></i> Inactive';
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const full_name = document.getElementById('edit-name').value;
    const email = document.getElementById('edit-email').value;
    const messageDiv = document.getElementById('profile-message');
    
    try {
        const response = await fetch(`${API_URL}/api/student/profile/${currentStudent.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ full_name, email })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Update localStorage
            currentStudent.full_name = full_name;
            currentStudent.email = email;
            localStorage.setItem('student', JSON.stringify(currentStudent));
            
            messageDiv.innerHTML = '<p class="text-success"><i class="fas fa-check-circle"></i> Profile updated successfully!</p>';
            
            // Reload profile
            setTimeout(() => {
                loadProfile();
                messageDiv.innerHTML = '';
            }, 2000);
        } else {
            messageDiv.innerHTML = `<p class="text-danger"><i class="fas fa-exclamation-circle"></i> ${result.message}</p>`;
        }
    } catch (error) {
        console.error('Error updating profile:', error);
        messageDiv.innerHTML = '<p class="text-danger"><i class="fas fa-exclamation-circle"></i> Failed to update profile</p>';
    }
});
