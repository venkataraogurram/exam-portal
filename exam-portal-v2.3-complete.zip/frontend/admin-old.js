// Backend Elastic Beanstalk URL
const API_URL = 'http://exam-backend-env.eba-eepuvjyu.us-east-1.elasticbeanstalk.com';

let currentAdmin = null;
let currentExam = null;
let questions = [];

// ============ LOGIN ============
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_URL}/api/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentAdmin = result.username;
            document.getElementById('login-section').classList.add('hidden');
            document.getElementById('admin-section').classList.remove('hidden');
            document.getElementById('admin-name').textContent = `Welcome, ${currentAdmin}`;
            loadExams();
        } else {
            alert('Invalid credentials');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Login failed');
    }
});

function logout() {
    currentAdmin = null;
    document.getElementById('admin-section').classList.add('hidden');
    document.getElementById('login-section').classList.remove('hidden');
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

// ============ TABS ============
function showTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
    
    event.target.classList.add('active');
    document.getElementById(`${tab}-tab`).classList.remove('hidden');
    
    if (tab === 'exams') {
        loadExams();
    } else if (tab === 'students') {
        loadStudents();
    } else if (tab === 'results') {
        loadResults();
    }
}

// ============ EXAMS ============
async function loadExams() {
    try {
        const response = await fetch(`${API_URL}/api/admin/exams`);
        const exams = await response.json();
        
        const examsList = document.getElementById('exams-list');
        examsList.innerHTML = exams.map(exam => `
            <div class="exam-item">
                <div class="exam-info">
                    <h3>${exam.title}</h3>
                    <p>${exam.questions.length} questions</p>
                </div>
                <div class="exam-actions">
                    <button class="btn btn-small" onclick="editExam(${exam.id})">Edit</button>
                    <button class="btn btn-small btn-danger" onclick="deleteExam(${exam.id})">Delete</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading exams:', error);
    }
}

function showCreateExam() {
    currentExam = null;
    questions = [];
    document.getElementById('modal-title').textContent = 'Create New Exam';
    document.getElementById('exam-title').value = '';
    document.getElementById('questions-list').innerHTML = '';
    document.getElementById('exam-modal').classList.remove('hidden');
}

async function editExam(examId) {
    try {
        const response = await fetch(`${API_URL}/api/admin/exams`);
        const exams = await response.json();
        currentExam = exams.find(e => e.id === examId);
        
        if (currentExam) {
            questions = [...currentExam.questions];
            document.getElementById('modal-title').textContent = 'Edit Exam';
            document.getElementById('exam-title').value = currentExam.title;
            renderQuestions();
            document.getElementById('exam-modal').classList.remove('hidden');
        }
    } catch (error) {
        console.error('Error loading exam:', error);
    }
}

async function deleteExam(examId) {
    if (!confirm('Are you sure you want to delete this exam?')) return;
    
    try {
        await fetch(`${API_URL}/api/admin/exams/${examId}`, {
            method: 'DELETE'
        });
        loadExams();
    } catch (error) {
        console.error('Error deleting exam:', error);
    }
}

async function saveExam() {
    const title = document.getElementById('exam-title').value;
    
    if (!title) {
        alert('Please enter exam title');
        return;
    }
    
    if (questions.length === 0) {
        alert('Please add at least one question');
        return;
    }
    
    try {
        if (currentExam) {
            // Update existing exam
            await fetch(`${API_URL}/api/admin/exams/${currentExam.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title })
            });
            
            // Delete old questions and add new ones
            for (const q of currentExam.questions) {
                await fetch(`${API_URL}/api/admin/exams/${currentExam.id}/questions/${q.id}`, {
                    method: 'DELETE'
                });
            }
            
            for (const q of questions) {
                await fetch(`${API_URL}/api/admin/exams/${currentExam.id}/questions`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(q)
                });
            }
        } else {
            // Create new exam
            const examResponse = await fetch(`${API_URL}/api/admin/exams`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title })
            });
            
            const examResult = await examResponse.json();
            const newExamId = examResult.exam.id;
            
            // Add questions
            for (const q of questions) {
                await fetch(`${API_URL}/api/admin/exams/${newExamId}/questions`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(q)
                });
            }
        }
        
        closeModal();
        loadExams();
    } catch (error) {
        console.error('Error saving exam:', error);
        alert('Failed to save exam');
    }
}

function closeModal() {
    document.getElementById('exam-modal').classList.add('hidden');
}

// ============ QUESTIONS ============
function addQuestion() {
    questions.push({
        question: '',
        options: ['', '', '', ''],
        correct: 0
    });
    renderQuestions();
}

function renderQuestions() {
    const questionsList = document.getElementById('questions-list');
    questionsList.innerHTML = questions.map((q, idx) => `
        <div class="question-item">
            <label>Question ${idx + 1}</label>
            <input type="text" value="${q.question}" onchange="updateQuestion(${idx}, 'question', this.value)" placeholder="Enter question">
            
            <div class="options-group">
                <label>Options (select correct answer):</label>
                ${q.options.map((opt, optIdx) => `
                    <div class="option-input">
                        <input type="radio" name="correct-${idx}" ${q.correct === optIdx ? 'checked' : ''} onchange="updateQuestion(${idx}, 'correct', ${optIdx})">
                        <input type="text" value="${opt}" onchange="updateOption(${idx}, ${optIdx}, this.value)" placeholder="Option ${optIdx + 1}">
                    </div>
                `).join('')}
            </div>
            
            <div class="question-actions">
                <button class="btn btn-small btn-danger" onclick="removeQuestion(${idx})">Remove Question</button>
            </div>
        </div>
    `).join('');
}

function updateQuestion(idx, field, value) {
    questions[idx][field] = value;
}

function updateOption(qIdx, optIdx, value) {
    questions[qIdx].options[optIdx] = value;
}

function removeQuestion(idx) {
    questions.splice(idx, 1);
    renderQuestions();
}

// ============ RESULTS ============
async function loadResults() {
    try {
        const response = await fetch(`${API_URL}/api/admin/results`);
        const results = await response.json();
        
        const resultsList = document.getElementById('results-list');
        
        if (results.length === 0) {
            resultsList.innerHTML = '<p>No results yet</p>';
            return;
        }
        
        resultsList.innerHTML = results.map(result => `
            <div class="result-item">
                <div>
                    <strong>Exam:</strong> ${result.exam_title}<br>
                    ${result.student_name ? `<strong>Student:</strong> ${result.student_name} (${result.student_email})<br>` : ''}
                    <small>${result.timestamp || 'N/A'}</small>
                </div>
                <div class="result-score">
                    Score: ${result.score} / ${result.total} (${Math.round((result.score / result.total) * 100)}%)
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading results:', error);
    }
}


// ============ STUDENT MANAGEMENT ============
async function loadStudents() {
    try {
        const response = await fetch(`${API_URL}/api/admin/students`);
        const students = await response.json();
        
        const studentsList = document.getElementById('students-list');
        studentsList.innerHTML = students.map(student => `
            <div class="exam-item">
                <div class="exam-info">
                    <h3>${student.full_name}</h3>
                    <p>${student.email}</p>
                    <small>Joined: ${new Date(student.created_at).toLocaleDateString()}</small>
                    <span style="margin-left: 15px; color: ${student.is_active ? '#28a745' : '#dc3545'};">
                        ${student.is_active ? '● Active' : '● Inactive'}
                    </span>
                </div>
                <div class="exam-actions">
                    <button class="btn btn-small ${student.is_active ? 'btn-secondary' : ''}" 
                            onclick="toggleStudentStatus(${student.id}, ${!student.is_active})">
                        ${student.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button class="btn btn-small" onclick="resetStudentPassword(${student.id})">Reset Password</button>
                    <button class="btn btn-small btn-danger" onclick="deleteStudent(${student.id})">Delete</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

function showCreateStudent() {
    document.getElementById('student-modal-title').textContent = 'Add New Student';
    document.getElementById('student-name').value = '';
    document.getElementById('student-email').value = '';
    document.getElementById('student-password').value = '';
    document.getElementById('student-message').innerHTML = '';
    document.getElementById('student-modal').classList.remove('hidden');
}

function closeStudentModal() {
    document.getElementById('student-modal').classList.add('hidden');
}

async function saveStudent() {
    const full_name = document.getElementById('student-name').value;
    const email = document.getElementById('student-email').value;
    const password = document.getElementById('student-password').value || 'student123';
    const messageDiv = document.getElementById('student-message');
    
    if (!full_name || !email) {
        messageDiv.innerHTML = '<p style="color: #dc3545;">Name and email are required</p>';
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/api/admin/students`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, full_name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<p style="color: #28a745;">Student added successfully!</p>';
            setTimeout(() => {
                closeStudentModal();
                loadStudents();
            }, 1000);
        } else {
            messageDiv.innerHTML = `<p style="color: #dc3545;">${result.message}</p>`;
        }
    } catch (error) {
        console.error('Error saving student:', error);
        messageDiv.innerHTML = '<p style="color: #dc3545;">Failed to save student</p>';
    }
}

async function toggleStudentStatus(studentId, isActive) {
    try {
        await fetch(`${API_URL}/api/admin/students/${studentId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ is_active: isActive })
        });
        loadStudents();
    } catch (error) {
        console.error('Error updating student status:', error);
    }
}

async function deleteStudent(studentId) {
    if (!confirm('Are you sure you want to delete this student? This will also delete their results.')) return;
    
    try {
        await fetch(`${API_URL}/api/admin/students/${studentId}`, {
            method: 'DELETE'
        });
        loadStudents();
    } catch (error) {
        console.error('Error deleting student:', error);
    }
}

async function resetStudentPassword(studentId) {
    const newPassword = prompt('Enter new password for student:', 'student123');
    if (!newPassword) return;
    
    try {
        const response = await fetch(`${API_URL}/api/admin/students/${studentId}/reset-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ new_password: newPassword })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Password reset successfully!');
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        alert('Failed to reset password');
    }
}
