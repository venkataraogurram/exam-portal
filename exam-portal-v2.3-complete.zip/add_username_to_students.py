#!/usr/bin/env python3
"""
Add username column to students table
"""

import pymysql

DB_CONFIG = {
    'host': 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'Admin123',
    'database': 'examportal',
    'port': 3306,
    'charset': 'utf8mb4'
}

def add_username_column():
    print("Connecting to database...")
    connection = pymysql.connect(**DB_CONFIG)
    
    try:
        cursor = connection.cursor()
        
        # Check if username column exists
        cursor.execute("""
            SELECT COUNT(*) as count 
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = 'examportal' 
            AND TABLE_NAME = 'students' 
            AND COLUMN_NAME = 'username'
        """)
        result = cursor.fetchone()
        
        if result[0] == 0:
            print("Adding username column to students table...")
            cursor.execute("""
                ALTER TABLE students 
                ADD COLUMN username VARCHAR(50) UNIQUE AFTER id
            """)
            connection.commit()
            print("✓ Username column added successfully!")
        else:
            print("✓ Username column already exists")
        
        cursor.close()
        connection.close()
        print("\n✓ Migration completed successfully!")
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        connection.rollback()
        connection.close()
        return False
    
    return True

if __name__ == '__main__':
    add_username_column()
