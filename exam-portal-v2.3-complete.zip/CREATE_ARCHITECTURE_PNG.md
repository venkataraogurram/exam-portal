# How to Create Architecture PNG

## Option 1: Using draw.io (Recommended - Free)

### Online Method (Easiest):
1. Go to https://app.diagrams.net/
2. Click "Open Existing Diagram"
3. Upload `architecture-diagram.drawio` file
4. The diagram will open with all AWS icons
5. Click "File" → "Export as" → "PNG"
6. Choose quality (300 DPI recommended)
7. Click "Export"
8. Save as `architecture.png`

### Desktop Method:
1. Download draw.io desktop app from https://github.com/jgraph/drawio-desktop/releases
2. Install and open the app
3. Open `architecture-diagram.drawio`
4. File → Export as → PNG
5. Save as `architecture.png`

## Option 2: Using Python (Automated)

Install required packages:
```bash
pip install diagrams
```

Create and run this Python script:

```python
# create_architecture.py
from diagrams import Diagram, Cluster, Edge
from diagrams.aws.network import Route53, ELB, ALB
from diagrams.aws.compute import ElasticBeanstalk, EC2
from diagrams.aws.database import RDS
from diagrams.aws.security import CertificateManager
from diagrams.aws.management import Cloudwatch
from diagrams.aws.storage import S3
from diagrams.onprem.client import Users

with Diagram("Exam Portal - AWS Architecture", 
             filename="architecture", 
             show=False,
             direction="TB",
             graph_attr={"fontsize": "20", "bgcolor": "white"}):
    
    users = Users("Internet Users\n(Students, Admins)")
    
    with Cluster("DNS & Security"):
        dns = Route53("Route 53\nDNS Management")
        cert = CertificateManager("Certificate Manager\nSSL/TLS")
    
    with Cluster("Frontend"):
        with Cluster("exam-frontend-env"):
            alb_frontend = ALB("Application\nLoad Balancer\nHTTPS:443")
            eb_frontend = ElasticBeanstalk("Elastic Beanstalk\nStatic Files")
            ec2_frontend = EC2("EC2 Instances\nNginx")
    
    with Cluster("Backend"):
        with Cluster("exam-backend-alb"):
            alb_backend = ALB("Application\nLoad Balancer\nHTTPS:443")
            eb_backend = ElasticBeanstalk("Elastic Beanstalk\nFlask API")
            ec2_backend = EC2("EC2 Instances\nPython/Flask")
    
    with Cluster("Database"):
        rds = RDS("RDS MySQL\nexamportal")
    
    with Cluster("Monitoring & Storage"):
        cloudwatch = Cloudwatch("CloudWatch\nLogs & Metrics")
        s3 = S3("S3\nApp Versions")
    
    # Connections
    users >> Edge(label="HTTPS") >> dns
    dns >> cert
    cert >> alb_frontend
    cert >> alb_backend
    alb_frontend >> eb_frontend >> ec2_frontend
    alb_backend >> eb_backend >> ec2_backend
    ec2_backend >> Edge(label="MySQL:3306") >> rds
    
    [eb_frontend, eb_backend] >> cloudwatch
    [eb_frontend, eb_backend] >> s3

print("Architecture diagram created as 'architecture.png'")
```

Run the script:
```bash
python3 create_architecture.py
```

This will generate `architecture.png` in the current directory.

## Option 3: Using Lucidchart (Professional)

1. Go to https://www.lucidchart.com/
2. Sign up for free account
3. Create new document
4. Use AWS Architecture shapes library
5. Recreate the architecture from ARCHITECTURE.md
6. Export as PNG (File → Download → PNG)

## Option 4: Using AWS Architecture Icons (Manual)

1. Download AWS Architecture Icons: https://aws.amazon.com/architecture/icons/
2. Use PowerPoint, Keynote, or any design tool
3. Arrange icons according to ARCHITECTURE.md
4. Export as PNG

## Option 5: Using Cloudcraft (AWS Specific)

1. Go to https://www.cloudcraft.co/
2. Sign up for free account
3. Use drag-and-drop AWS components
4. Export as PNG (Pro feature) or screenshot

## Recommended Settings for PNG Export:

- **Resolution**: 300 DPI (for print quality)
- **Size**: 1920x1080 or larger
- **Format**: PNG with transparent background
- **Quality**: High/Maximum

## After Creating the PNG:

1. Save the file as `architecture.png` in the project root
2. Update README.md to reference the image:
   ```markdown
   ![AWS Architecture](architecture.png)
   ```
3. Commit and push to GitHub

## Quick Screenshot Method (Temporary):

If you need a quick diagram:
1. Open ARCHITECTURE.md
2. Take a screenshot of the ASCII diagram
3. Save as `architecture.png`
4. (Not recommended for professional use)

---

**Recommended**: Use Option 1 (draw.io) or Option 2 (Python diagrams) for best results.
