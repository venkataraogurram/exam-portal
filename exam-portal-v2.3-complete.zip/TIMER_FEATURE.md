# Exam Timer Feature Documentation

## Overview
The exam timer feature provides a countdown timer for each exam, automatically submitting the exam when time expires. This ensures fair time limits for all students.

## Features

### 1. Configurable Duration
- Admins can set exam duration when creating or editing exams
- Default duration: 30 minutes
- Minimum duration: 1 minute
- Duration is stored in the database and displayed to students

### 2. Visual Timer Display
- Timer appears in the exam header when student starts an exam
- Shows countdown in MM:SS format (e.g., 29:45)
- Color-coded warnings:
  - **Purple gradient**: Normal time remaining (> 5 minutes)
  - **Orange gradient**: Warning - 5 minutes or less remaining
  - **Red gradient with pulse**: Critical - 1 minute or less remaining

### 3. Time Warnings
- **5-minute warning**: Alert shown when 5 minutes remain
- **1-minute warning**: Alert shown when 1 minute remains
- Pulse animation on timer when critical (< 1 minute)

### 4. Auto-Submit
- Exam automatically submits when timer reaches 00:00
- Student receives notification: "Time's up! Submitting your exam..."
- Prevents students from continuing after time expires

### 5. Manual Submit
- Students can submit exam before time expires
- Timer stops when exam is manually submitted
- Timer stops when navigating back to dashboard

## Implementation Details

### Database Schema
```sql
ALTER TABLE exams 
ADD COLUMN duration INT DEFAULT 30 COMMENT 'Exam duration in minutes';
```

### Backend Changes

#### database.py
```python
@staticmethod
def create_exam(title, duration=30):
    # Creates exam with duration
    
@staticmethod
def update_exam(exam_id, title, duration=None):
    # Updates exam including duration
```

#### app.py
```python
@app.route('/api/admin/exams', methods=['POST'])
def admin_create_exam():
    duration = data.get('duration', 30)
    exam_id = DB.create_exam(title, duration)
    
@app.route('/api/admin/exams/<int:exam_id>', methods=['PUT'])
def admin_update_exam(exam_id):
    duration = data.get('duration')
    DB.update_exam(exam_id, title, duration)
```

### Frontend Changes

#### admin.js
- Added duration input field to exam creation/edit modal
- Duration field with default value of 30 minutes
- Duration displayed in exam cards in admin console
- Duration sent to backend when creating/updating exams

#### student-dashboard.js
- Timer variables: `timerInterval`, `timeRemaining`
- `startTimer()`: Initializes and starts countdown
- `updateTimerDisplay()`: Updates timer display and colors
- `stopTimer()`: Stops timer when exam ends
- Timer automatically starts when exam loads
- Timer stops on manual submit or navigation

#### modern-style.css
- Pulse animation for critical timer state
- Color transitions for warning states
- Responsive timer display

## Usage

### For Admins

#### Creating Exam with Timer
1. Click "Create Exam" button
2. Enter exam title
3. Set duration in minutes (default: 30)
4. Add questions
5. Save exam

#### Editing Exam Duration
1. Click "Edit" on existing exam
2. Modify duration field
3. Save changes

### For Students

#### Taking Timed Exam
1. Click on exam to start
2. Timer appears in exam header
3. Answer questions before time expires
4. Submit manually or wait for auto-submit

#### Timer Behavior
- Timer counts down from exam duration
- Orange color at 5 minutes remaining
- Red color with pulse at 1 minute remaining
- Auto-submits at 00:00

## Database Migration

### Option 1: SQL Script
```bash
# Connect to RDS
mysql -h venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com \
      -u admin -pAdmin123 -D examportal < add_duration_column.sql
```

### Option 2: Python Script
```bash
# On EC2 instance
python3 add_duration_to_exams.py
```

### Option 3: Manual SQL
```sql
-- Connect to database and run:
ALTER TABLE exams ADD COLUMN duration INT DEFAULT 30;
UPDATE exams SET duration = 30 WHERE duration IS NULL;
```

## Testing Checklist

### Admin Console
- [ ] Create new exam with custom duration
- [ ] Edit existing exam duration
- [ ] Verify duration displays in exam list
- [ ] Verify duration saves to database

### Student Dashboard
- [ ] Timer appears when exam starts
- [ ] Timer counts down correctly
- [ ] Timer shows correct duration from database
- [ ] Orange warning at 5 minutes
- [ ] Red warning with pulse at 1 minute
- [ ] Alert at 5 minutes remaining
- [ ] Alert at 1 minute remaining
- [ ] Auto-submit at 00:00
- [ ] Timer stops on manual submit
- [ ] Timer stops when navigating away

### Edge Cases
- [ ] Exam with 1-minute duration
- [ ] Exam with very long duration (e.g., 120 minutes)
- [ ] Multiple exams with different durations
- [ ] Timer persists on page refresh (should restart exam)

## Deployment Steps

1. **Update Database Schema**
   ```bash
   # SSH to EC2 instance
   ssh ec2-user@<ec2-ip>
   
   # Run migration script
   python3 add_duration_to_exams.py
   ```

2. **Deploy Backend**
   ```bash
   cd backend
   eb deploy exam-backend-alb
   ```

3. **Deploy Frontend**
   ```bash
   cd frontend
   eb deploy exam-frontend-alb
   ```

4. **Verify Deployment**
   - Test admin console: https://exam.venkatgh.people.aws.dev/admin.html
   - Test student dashboard: https://exam.venkatgh.people.aws.dev/student-dashboard.html
   - Create test exam with custom duration
   - Take test exam and verify timer works

## Troubleshooting

### Timer Not Appearing
- Check browser console for JavaScript errors
- Verify exam has duration field in database
- Check API response includes duration

### Timer Not Counting Down
- Check `startTimer()` is called after exam loads
- Verify `setInterval` is working
- Check for JavaScript errors in console

### Auto-Submit Not Working
- Verify timer reaches 00:00
- Check submit event is triggered
- Verify backend receives submission

### Duration Not Saving
- Check admin.js sends duration in request
- Verify backend receives duration parameter
- Check database column exists

## Future Enhancements

1. **Pause/Resume**: Allow pausing timer (with admin permission)
2. **Time Extensions**: Admin can extend time for specific students
3. **Time Tracking**: Log when student started exam
4. **Remaining Time Display**: Show time remaining in exam list
5. **Time Zones**: Handle different time zones for scheduled exams
6. **Grace Period**: Allow small grace period after time expires
7. **Progress Save**: Auto-save answers periodically during exam

## Version History

- **v2.2** (Dec 2025): Initial timer feature implementation
  - Configurable exam duration
  - Visual countdown timer
  - Color-coded warnings
  - Auto-submit on timeout
  - Pulse animation for critical time

## Support

For issues or questions:
- Check browser console for errors
- Verify database schema is updated
- Review deployment logs
- Test with different exam durations
