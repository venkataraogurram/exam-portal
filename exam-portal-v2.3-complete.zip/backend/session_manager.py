"""
Session Management Module
Handles JWT token generation, validation, and session tracking
"""

import jwt
import datetime
from functools import wraps
from flask import request, jsonify
import os

# Secret key for JWT - should be in environment variable in production
SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
ALGORITHM = 'HS256'

# Token expiration times
STUDENT_TOKEN_EXPIRY = 24  # hours
ADMIN_TOKEN_EXPIRY = 8     # hours

class SessionManager:
    """Manages user sessions using JWT tokens"""
    
    @staticmethod
    def generate_token(user_id, user_type, username=None, email=None, full_name=None, is_root=False):
        """
        Generate JWT token for user
        
        Args:
            user_id: User ID
            user_type: 'student' or 'admin'
            username: Username (optional)
            email: Email (optional)
            full_name: Full name (optional)
            is_root: Is root admin (for admin type)
        
        Returns:
            JWT token string
        """
        expiry_hours = ADMIN_TOKEN_EXPIRY if user_type == 'admin' else STUDENT_TOKEN_EXPIRY
        
        payload = {
            'user_id': user_id,
            'user_type': user_type,
            'username': username,
            'email': email,
            'full_name': full_name,
            'is_root': is_root if user_type == 'admin' else None,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=expiry_hours),
            'iat': datetime.datetime.utcnow()
        }
        
        token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
        return token
    
    @staticmethod
    def verify_token(token):
        """
        Verify and decode JWT token
        
        Args:
            token: JWT token string
        
        Returns:
            Decoded payload if valid, None if invalid
        """
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            return None  # Token expired
        except jwt.InvalidTokenError:
            return None  # Invalid token
    
    @staticmethod
    def refresh_token(token):
        """
        Refresh an existing token (extend expiration)
        
        Args:
            token: Current JWT token
        
        Returns:
            New token if valid, None if invalid
        """
        payload = SessionManager.verify_token(token)
        if payload:
            # Remove old expiration and issued at
            payload.pop('exp', None)
            payload.pop('iat', None)
            
            # Generate new token with same data
            return SessionManager.generate_token(
                user_id=payload['user_id'],
                user_type=payload['user_type'],
                username=payload.get('username'),
                email=payload.get('email'),
                full_name=payload.get('full_name'),
                is_root=payload.get('is_root', False)
            )
        return None


def require_auth(user_type=None):
    """
    Decorator to require authentication for routes
    
    Args:
        user_type: 'student', 'admin', or None (any authenticated user)
    
    Usage:
        @app.route('/api/protected')
        @require_auth('student')
        def protected_route():
            # Access current_user from request
            user = request.current_user
            return jsonify(user)
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get token from Authorization header
            auth_header = request.headers.get('Authorization')
            
            if not auth_header:
                return jsonify({'error': 'No authorization token provided', 'auth_required': True}), 401
            
            # Extract token (format: "Bearer <token>")
            try:
                token = auth_header.split(' ')[1] if ' ' in auth_header else auth_header
            except IndexError:
                return jsonify({'error': 'Invalid authorization header format', 'auth_required': True}), 401
            
            # Verify token
            payload = SessionManager.verify_token(token)
            
            if not payload:
                return jsonify({'error': 'Invalid or expired token', 'auth_required': True}), 401
            
            # Check user type if specified
            if user_type and payload.get('user_type') != user_type:
                return jsonify({'error': 'Unauthorized user type', 'auth_required': True}), 403
            
            # Attach user info to request
            request.current_user = payload
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def optional_auth():
    """
    Decorator for routes that work with or without authentication
    Attaches user info if token is valid, but doesn't require it
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            auth_header = request.headers.get('Authorization')
            
            if auth_header:
                try:
                    token = auth_header.split(' ')[1] if ' ' in auth_header else auth_header
                    payload = SessionManager.verify_token(token)
                    request.current_user = payload if payload else None
                except:
                    request.current_user = None
            else:
                request.current_user = None
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator
