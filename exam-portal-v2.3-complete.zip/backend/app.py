from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import os
import re

app = Flask(__name__)
CORS(app)

# Import database functions but don't initialize on startup
from database import DB, init_database, get_db_connection
from session_manager import SessionManager, require_auth, optional_auth

@app.route('/')
def home():
    return jsonify({"message": "Exam Portal API", "status": "running"})

@app.route('/api/init-db', methods=['POST'])
def initialize_database():
    """Manual database initialization endpoint"""
    try:
        init_database()
        return jsonify({"success": True, "message": "Database initialized successfully"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

# ============ ADMIN AUTHENTICATION ============
@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    user = DB.verify_admin(username, password)
    if user:
        # Generate JWT token
        token = SessionManager.generate_token(
            user_id=user['id'],
            user_type='admin',
            username=username,
            is_root=user['id'] == 1
        )
        
        return jsonify({
            "success": True, 
            "message": "Login successful", 
            "token": token,
            "user": {
                "username": username,
                "admin_id": user['id'],
                "is_root": user['id'] == 1
            }
        })
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

# ============ ADMIN MANAGEMENT (ROOT ADMIN ONLY) ============
@app.route('/api/admin/admins', methods=['GET'])
def get_all_admins():
    admins = DB.get_all_admins()
    return jsonify([
        {
            "id": a['id'],
            "username": a['username'],
            "is_root": a['id'] == 1,
            "created_at": a['created_at'].isoformat() if a['created_at'] else None
        }
        for a in admins
    ])

@app.route('/api/admin/admins', methods=['POST'])
def create_admin():
    data = request.json
    username = data.get('username')
    password = data.get('password', 'admin123')
    
    if not username:
        return jsonify({"success": False, "message": "Username is required"}), 400
    
    # Check if admin already exists
    existing = DB.get_admin_by_username(username)
    if existing:
        return jsonify({"success": False, "message": "Username already exists"}), 400
    
    admin_id = DB.create_admin(username, password)
    return jsonify({"success": True, "admin_id": admin_id}), 201

@app.route('/api/admin/admins/<int:admin_id>', methods=['PUT'])
def update_admin(admin_id):
    data = request.json
    new_password = data.get('password')
    
    if not new_password:
        return jsonify({"success": False, "message": "Password is required"}), 400
    
    if DB.update_admin_password(admin_id, new_password):
        return jsonify({"success": True, "message": "Password updated successfully"})
    return jsonify({"success": False, "message": "Admin not found"}), 404

@app.route('/api/admin/admins/<int:admin_id>', methods=['DELETE'])
def delete_admin(admin_id):
    if admin_id == 1:
        return jsonify({"success": False, "message": "Cannot delete root admin"}), 403
    
    if DB.delete_admin(admin_id):
        return jsonify({"success": True, "message": "Admin deleted successfully"})
    return jsonify({"success": False, "message": "Admin not found or cannot be deleted"}), 404

# ============ EXAM MANAGEMENT (ADMIN) ============
@app.route('/api/admin/exams', methods=['GET'])
def admin_get_all_exams():
    exams = DB.get_all_exams()
    result = []
    for exam in exams:
        exam_detail = DB.get_exam_with_questions(exam['id'])
        result.append(exam_detail)
    return jsonify(result)

@app.route('/api/admin/exams', methods=['POST'])
def admin_create_exam():
    data = request.json
    title = data.get('title', 'Untitled Exam')
    duration = data.get('duration', 30)
    exam_id = DB.create_exam(title, duration)
    return jsonify({"success": True, "exam": {"id": exam_id, "title": title, "duration": duration, "questions": []}}), 201

@app.route('/api/admin/exams/<int:exam_id>', methods=['PUT'])
def admin_update_exam(exam_id):
    data = request.json
    title = data.get('title')
    duration = data.get('duration')
    
    if DB.update_exam(exam_id, title, duration):
        exam = DB.get_exam_with_questions(exam_id)
        return jsonify({"success": True, "exam": exam})
    return jsonify({"error": "Exam not found"}), 404

@app.route('/api/admin/exams/<int:exam_id>', methods=['DELETE'])
def admin_delete_exam(exam_id):
    if DB.delete_exam(exam_id):
        return jsonify({"success": True, "message": "Exam deleted"})
    return jsonify({"error": "Exam not found"}), 404

# ============ QUESTION MANAGEMENT (ADMIN) ============
@app.route('/api/admin/exams/<int:exam_id>/questions', methods=['POST'])
def admin_add_question(exam_id):
    data = request.json
    question = data.get('question', '')
    options = data.get('options', ['', '', '', ''])
    correct = data.get('correct', 0)
    
    question_id = DB.add_question(exam_id, question, options, correct)
    
    return jsonify({
        "success": True,
        "question": {
            "id": question_id,
            "question": question,
            "options": options,
            "correct": correct
        }
    }), 201

@app.route('/api/admin/exams/<int:exam_id>/questions/<int:question_id>', methods=['DELETE'])
def admin_delete_question(exam_id, question_id):
    if DB.delete_question(question_id):
        return jsonify({"success": True, "message": "Question deleted"})
    return jsonify({"error": "Question not found"}), 404

@app.route('/api/admin/exams/<int:exam_id>/assign', methods=['POST'])
def assign_exam_to_students(exam_id):
    data = request.json
    student_ids = data.get('student_ids', [])
    
    try:
        DB.assign_exam_to_students(exam_id, student_ids)
        return jsonify({"success": True, "message": "Exam assigned successfully"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/exams/<int:exam_id>/assignments', methods=['GET'])
def get_exam_assignments(exam_id):
    try:
        assignments = DB.get_exam_assignments(exam_id)
        return jsonify([
            {
                "id": a['id'],
                "username": a.get('username'),
                "email": a['email'],
                "full_name": a['full_name']
            }
            for a in assignments
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============ EXAM IMPORT FROM FILE ============
@app.route('/api/admin/exams/import', methods=['POST'])
def import_exam_from_text():
    try:
        data = request.json
        file_content = data.get('content', '')
        
        if not file_content:
            return jsonify({"success": False, "message": "No content provided"}), 400
        
        # Parse the file content
        lines = file_content.strip().split('\n')
        exam_title = "Imported Exam"
        questions = []
        current_question = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if line.startswith('EXAM_TITLE:'):
                exam_title = line.replace('EXAM_TITLE:', '').strip()
            
            elif line.startswith('QUESTION:'):
                if current_question:
                    questions.append(current_question)
                current_question = {
                    'question': line.replace('QUESTION:', '').strip(),
                    'options': [],
                    'correct': 0
                }
            
            elif line.startswith(('A)', 'B)', 'C)', 'D)')):
                if current_question:
                    option_text = line[3:].strip()  # Remove "A) ", "B) ", etc.
                    current_question['options'].append(option_text)
            
            elif line.startswith('CORRECT:'):
                if current_question:
                    correct_letter = line.replace('CORRECT:', '').strip()
                    correct_map = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
                    current_question['correct'] = correct_map.get(correct_letter, 0)
        
        # Add the last question
        if current_question:
            questions.append(current_question)
        
        # Validate
        if not questions:
            return jsonify({"success": False, "message": "No valid questions found in file"}), 400
        
        # Create exam
        exam_id = DB.create_exam(exam_title)
        
        # Add questions
        for q in questions:
            if len(q['options']) == 4:  # Ensure we have 4 options
                DB.add_question(exam_id, q['question'], q['options'], q['correct'])
        
        return jsonify({
            "success": True,
            "message": f"Exam imported successfully with {len(questions)} questions",
            "exam_id": exam_id,
            "exam_title": exam_title
        }), 201
    
    except Exception as e:
        return jsonify({"success": False, "message": f"Import failed: {str(e)}"}), 500

# ============ STUDENT APIS ============
@app.route('/api/exams', methods=['GET'])
def get_exams():
    student_id = request.args.get('student_id')
    
    if student_id:
        # Get exams assigned to this student
        exams = DB.get_student_assigned_exams(int(student_id))
    else:
        # Get all exams (for backward compatibility)
        exams = DB.get_all_exams()
    
    return jsonify(exams)

@app.route('/api/exams/<int:exam_id>', methods=['GET'])
def get_exam(exam_id):
    exam = DB.get_exam_with_questions(exam_id)
    if exam:
        return jsonify(exam)
    return jsonify({"error": "Exam not found"}), 404

@app.route('/api/submit', methods=['POST'])
def submit_exam():
    data = request.json
    exam_id = data.get('exam_id')
    answers = data.get('answers', {})
    student_id = data.get('student_id')  # Optional
    
    exam = DB.get_exam_with_questions(exam_id)
    if not exam:
        return jsonify({"error": "Exam not found"}), 404
    
    score = 0
    total = len(exam["questions"])
    
    for q in exam["questions"]:
        if str(q["id"]) in answers and answers[str(q["id"])] == q["correct"]:
            score += 1
    
    if student_id:
        DB.save_result_with_student(exam_id, student_id, score, total)
    else:
        DB.save_result(exam_id, score, total)
    
    return jsonify({
        "exam_id": exam_id,
        "score": score,
        "total": total,
        "timestamp": datetime.now().isoformat()
    })

# ============ ADMIN RESULTS ============
@app.route('/api/admin/results', methods=['GET'])
def admin_get_results():
    results = DB.get_all_results_with_students()
    return jsonify([
        {
            "id": r['id'],
            "exam_id": r['exam_id'],
            "exam_title": r['exam_title'],
            "student_email": r.get('student_email'),
            "student_name": r.get('student_name'),
            "score": r['score'],
            "total": r['total'],
            "timestamp": r['submitted_at'].isoformat() if r['submitted_at'] else None
        }
        for r in results
    ])

# ============ STUDENT AUTHENTICATION ============
@app.route('/api/student/register', methods=['POST'])
def student_register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')
    username = data.get('username')  # Optional
    
    if not email or not password or not full_name:
        return jsonify({"success": False, "message": "All fields are required"}), 400
    
    # Check if student already exists
    existing = DB.get_student_by_email(email)
    if existing:
        return jsonify({"success": False, "message": "Email already registered"}), 400
    
    # Check if username already exists
    if username:
        existing_username = DB.get_student_by_username(username)
        if existing_username:
            return jsonify({"success": False, "message": "Username already taken"}), 400
    
    student_id = DB.create_student(email, password, full_name, username)
    
    # Get the created student
    student = DB.get_student_by_id(student_id)
    
    # Generate JWT token for auto-login
    token = SessionManager.generate_token(
        user_id=student_id,
        user_type='student',
        username=student.get('username'),
        email=email,
        full_name=full_name
    )
    
    return jsonify({
        "success": True, 
        "message": "Registration successful", 
        "token": token,
        "student": {
            "id": student_id,
            "username": student.get('username'),
            "email": email,
            "full_name": full_name
        }
    }), 201

@app.route('/api/student/login', methods=['POST'])
def student_login():
    data = request.json
    login = data.get('email')  # Can be email or username
    password = data.get('password')
    
    student = DB.verify_student(login, password)
    if student:
        # Generate JWT token
        token = SessionManager.generate_token(
            user_id=student['id'],
            user_type='student',
            username=student.get('username'),
            email=student['email'],
            full_name=student['full_name']
        )
        
        return jsonify({
            "success": True,
            "message": "Login successful",
            "token": token,
            "student": {
                "id": student['id'],
                "username": student.get('username'),
                "email": student['email'],
                "full_name": student['full_name']
            }
        })
    return jsonify({"success": False, "message": "Invalid credentials or account inactive"}), 401

# ============ SESSION MANAGEMENT ============
@app.route('/api/auth/verify', methods=['POST'])
def verify_token():
    """Verify if a token is valid"""
    data = request.json
    token = data.get('token')
    
    if not token:
        return jsonify({"valid": False, "message": "No token provided"}), 400
    
    payload = SessionManager.verify_token(token)
    
    if payload:
        return jsonify({
            "valid": True,
            "user": {
                "user_id": payload['user_id'],
                "user_type": payload['user_type'],
                "username": payload.get('username'),
                "email": payload.get('email'),
                "full_name": payload.get('full_name'),
                "is_root": payload.get('is_root')
            }
        })
    
    return jsonify({"valid": False, "message": "Invalid or expired token"}), 401

@app.route('/api/auth/refresh', methods=['POST'])
def refresh_token():
    """Refresh an existing token"""
    data = request.json
    token = data.get('token')
    
    if not token:
        return jsonify({"success": False, "message": "No token provided"}), 400
    
    new_token = SessionManager.refresh_token(token)
    
    if new_token:
        return jsonify({"success": True, "token": new_token})
    
    return jsonify({"success": False, "message": "Invalid or expired token"}), 401

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    """Logout endpoint (client should delete token)"""
    return jsonify({"success": True, "message": "Logged out successfully"})

@app.route('/api/student/change-password', methods=['POST'])
@require_auth('student')
def student_change_password():
    data = request.json
    old_password = data.get('old_password')
    new_password = data.get('new_password')
    
    # Get current user from token
    current_user = request.current_user
    student_id = current_user['user_id']
    
    # Verify old password
    student = DB.get_student_by_id(student_id)
    if not student or student['password'] != old_password:
        return jsonify({"success": False, "message": "Invalid current password"}), 401
    
    DB.update_student_password(student_id, new_password)
    return jsonify({"success": True, "message": "Password changed successfully"})

@app.route('/api/student/forgot-password', methods=['POST'])
def student_forgot_password():
    data = request.json
    email = data.get('email')
    
    student = DB.get_student_by_email(email)
    if not student:
        return jsonify({"success": False, "message": "Email not found"}), 404
    
    # In production, send email with reset link
    # For now, return a simple message
    return jsonify({
        "success": True,
        "message": "Password reset instructions sent to your email",
        "note": "Contact admin to reset password"
    })

@app.route('/api/student/results/<int:student_id>', methods=['GET'])
def get_student_results(student_id):
    results = DB.get_student_results(student_id)
    return jsonify([
        {
            "id": r['id'],
            "exam_id": r['exam_id'],
            "exam_title": r['exam_title'],
            "score": r['score'],
            "total": r['total'],
            "timestamp": r['submitted_at'].isoformat() if r['submitted_at'] else None
        }
        for r in results
    ])

@app.route('/api/student/profile/<int:student_id>', methods=['GET'])
def get_student_profile(student_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, full_name, is_active, created_at FROM students WHERE id = %s", (student_id,))
        student = cursor.fetchone()
        
        if student:
            # Get stats
            cursor.execute("SELECT COUNT(*) as count FROM results WHERE student_id = %s", (student_id,))
            result = cursor.fetchone()
            completed = result['count'] if result else 0
            
            cursor.execute("SELECT AVG(score/total*100) as avg FROM results WHERE student_id = %s", (student_id,))
            result = cursor.fetchone()
            avg_score = round(result['avg'], 1) if result and result['avg'] else 0
            
            return jsonify({
                "id": student['id'],
                "email": student['email'],
                "full_name": student['full_name'],
                "is_active": bool(student['is_active']),
                "created_at": student['created_at'].isoformat() if student['created_at'] else None,
                "stats": {
                    "completed_exams": completed,
                    "average_score": avg_score
                }
            })
        return jsonify({"error": "Student not found"}), 404

@app.route('/api/student/profile/<int:student_id>', methods=['PUT'])
def update_student_profile(student_id):
    data = request.json
    full_name = data.get('full_name')
    email = data.get('email')
    
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE students SET full_name = %s, email = %s WHERE id = %s",
            (full_name, email, student_id)
        )
        conn.commit()
        
        if cursor.rowcount > 0:
            return jsonify({"success": True, "message": "Profile updated successfully"})
        return jsonify({"success": False, "message": "Student not found"}), 404

@app.route('/api/admin/profile', methods=['GET'])
def get_admin_profile():
    # For now, return static admin info
    return jsonify({
        "username": "admin",
        "role": "Administrator",
        "created_at": "2025-01-01T00:00:00"
    })

# ============ ADMIN STUDENT MANAGEMENT ============
@app.route('/api/admin/students', methods=['GET'])
def admin_get_students():
    students = DB.get_all_students()
    return jsonify([
        {
            "id": s['id'],
            "username": s.get('username'),
            "email": s['email'],
            "full_name": s['full_name'],
            "is_active": bool(s['is_active']),
            "created_at": s['created_at'].isoformat() if s['created_at'] else None
        }
        for s in students
    ])

@app.route('/api/admin/students', methods=['POST'])
def admin_create_student():
    data = request.json
    email = data.get('email')
    password = data.get('password', 'student123')
    full_name = data.get('full_name')
    username = data.get('username')  # Optional
    
    if not email or not full_name:
        return jsonify({"success": False, "message": "Email and name are required"}), 400
    
    existing = DB.get_student_by_email(email)
    if existing:
        return jsonify({"success": False, "message": "Email already exists"}), 400
    
    # Check if username already exists
    if username:
        existing_username = DB.get_student_by_username(username)
        if existing_username:
            return jsonify({"success": False, "message": "Username already taken"}), 400
    
    student_id = DB.create_student(email, password, full_name, username)
    return jsonify({"success": True, "student_id": student_id}), 201

@app.route('/api/admin/students/<int:student_id>', methods=['PUT'])
def admin_update_student_status(student_id):
    data = request.json
    is_active = data.get('is_active')
    
    # If only updating status
    if is_active is not None and len(data) == 1:
        if DB.update_student_status(student_id, is_active):
            return jsonify({"success": True})
        return jsonify({"success": False, "message": "Student not found"}), 404
    
    # If updating full details
    full_name = data.get('full_name')
    username = data.get('username')
    email = data.get('email')
    
    if DB.update_student_details(student_id, full_name, username, email):
        return jsonify({"success": True, "message": "Student updated successfully"})
    return jsonify({"success": False, "message": "Failed to update student"}), 400

@app.route('/api/admin/students/<int:student_id>', methods=['DELETE'])
def admin_delete_student(student_id):
    if DB.delete_student(student_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "Student not found"}), 404

@app.route('/api/admin/students/<int:student_id>/reset-password', methods=['POST'])
def admin_reset_student_password(student_id):
    data = request.json
    new_password = data.get('new_password', 'student123')
    
    if DB.update_student_password(student_id, new_password):
        return jsonify({"success": True, "message": "Password reset successfully"})
    return jsonify({"success": False, "message": "Student not found"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
