#!/usr/bin/env python3
"""
Script to initialize RDS database for Exam Portal
"""
import pymysql
import sys

# RDS Configuration
DB_CONFIG = {
    'host': 'venkat-rds.ccb68646w9ed.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'Venkat@123',
    'port': 3306,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def setup_database():
    """Initialize database and tables"""
    try:
        # Connect without database first
        print("Connecting to RDS...")
        connection = pymysql.connect(**DB_CONFIG)
        cursor = connection.cursor()
        
        # Create database if not exists
        print("Creating database 'examportal'...")
        cursor.execute("CREATE DATABASE IF NOT EXISTS examportal")
        cursor.execute("USE examportal")
        print("✓ Database 'examportal' ready")
        
        # Create admin_users table
        print("\nCreating 'admin_users' table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS admin_users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✓ Table 'admin_users' created")
        
        # Create exams table
        print("Creating 'exams' table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS exams (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        """)
        print("✓ Table 'exams' created")
        
        # Create questions table
        print("Creating 'questions' table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS questions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                exam_id INT NOT NULL,
                question TEXT NOT NULL,
                option1 VARCHAR(255) NOT NULL,
                option2 VARCHAR(255) NOT NULL,
                option3 VARCHAR(255) NOT NULL,
                option4 VARCHAR(255) NOT NULL,
                correct_option INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
            )
        """)
        print("✓ Table 'questions' created")
        
        # Create results table
        print("Creating 'results' table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                exam_id INT NOT NULL,
                score INT NOT NULL,
                total INT NOT NULL,
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
            )
        """)
        print("✓ Table 'results' created")
        
        # Insert default admin user if not exists
        print("\nChecking for default admin user...")
        cursor.execute("SELECT COUNT(*) as count FROM admin_users WHERE username = 'admin'")
        if cursor.fetchone()['count'] == 0:
            cursor.execute(
                "INSERT INTO admin_users (username, password) VALUES (%s, %s)",
                ('admin', 'admin123')
            )
            print("✓ Default admin user created (username: admin, password: admin123)")
        else:
            print("✓ Admin user already exists")
        
        # Insert sample exam if no exams exist
        print("\nChecking for sample data...")
        cursor.execute("SELECT COUNT(*) as count FROM exams")
        if cursor.fetchone()['count'] == 0:
            print("Creating sample exam...")
            cursor.execute("INSERT INTO exams (title) VALUES (%s)", ('Python Basics',))
            exam_id = cursor.lastrowid
            
            cursor.execute("""
                INSERT INTO questions (exam_id, question, option1, option2, option3, option4, correct_option)
                VALUES 
                (%s, %s, %s, %s, %s, %s, %s),
                (%s, %s, %s, %s, %s, %s, %s)
            """, (
                exam_id, 'What is Python?', 'A snake', 'A programming language', 'A framework', 'A database', 1,
                exam_id, 'What is a list in Python?', 'A data structure', 'A function', 'A class', 'A module', 0
            ))
            print("✓ Sample exam 'Python Basics' created with 2 questions")
        else:
            print("✓ Sample data already exists")
        
        connection.commit()
        
        # Show summary
        print("\n" + "="*50)
        print("DATABASE SETUP COMPLETE!")
        print("="*50)
        
        cursor.execute("SELECT COUNT(*) as count FROM admin_users")
        admin_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM exams")
        exam_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM questions")
        question_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM results")
        result_count = cursor.fetchone()['count']
        
        print(f"\nDatabase: examportal")
        print(f"Admin Users: {admin_count}")
        print(f"Exams: {exam_count}")
        print(f"Questions: {question_count}")
        print(f"Results: {result_count}")
        print("\n✓ All tables created successfully!")
        print("✓ Database is ready for use!")
        
        cursor.close()
        connection.close()
        
    except pymysql.Error as e:
        print(f"\n✗ Database error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    setup_database()
